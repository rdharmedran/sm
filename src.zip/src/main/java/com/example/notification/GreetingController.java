package com.example.notification;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

	private static final String template1 = "Hello, %s!";
	private final AtomicLong counter = new AtomicLong();
	 @Autowired
	    private SimpMessagingTemplate template;
	@GetMapping("/greeting")
	public void greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
		try {
	        while (true) {
	           // System.out.println(new Date());
	            template.convertAndSend("/topic/pushNotification", template1);
	            Thread.sleep(5 * 1000);
	        }
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }
	}
}