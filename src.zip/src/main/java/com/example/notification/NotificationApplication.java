package com.example.notification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
@SpringBootApplication
public class NotificationApplication {
	 @Autowired
	    private SimpMessagingTemplate template;
	public static void main(String[] args) {
		SpringApplication.run(NotificationApplication.class, args);
		
	}
	
}
