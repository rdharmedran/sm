package com.fpl.smdc;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

@Service
public class CacheScheduler {
    @Autowired
    ErrorDetailDAO errorDao;
    @Autowired
    CacheManager cacheManager;

    @PostConstruct
    public void init() {
        update();
      
    }

    public void update() {
    	 System.out.println("NNNNNNNNNNNNNNNNNNbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbNNNNNNNNNNNNN");
    System.out.println("tttttttttttttttttt"+errorDao.findAll().isEmpty());
    	 for (ErrorDetail error : errorDao.findAll()) {
            cacheManager.getCache("errors").put(error.getErrorType(), error);
            System.out.println(error.getErrorType()+"NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN"+error);
          
        }
    }
}