package com.fpl.smdc;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Test {

	public static void main(String[] args) {
		 Map<String,  Category> result =new HashMap();
		 Test test=new Test();
		List layerList =new ArrayList<>();
		layerList.add(new Layer("layer1","1","","1/"));
		layerList.add(new Layer("layer2","2","1","1/2/"));		
		layerList.add(new Layer("layer3","3","1","1/3"));	
		layerList.add(new Layer("layer4","4","2","1/2/4/"));	
		layerList.add(new Layer("layer3","7","2","1/2/7"));	
		layerList.add(new Layer("layer1","5","","5/"));
		layerList.add(new Layer("layer2","9","5","5/9/"));		
		layerList.add(new Layer("layer3","10","9","5/9/10/"));	
	
		List<Layer> sortedUsers = (List<Layer>) layerList.stream()
				  .sorted(Comparator.comparing(Layer::getLineage))
				  .collect(Collectors.toList());
		
		for(Layer layer:sortedUsers) {
			System.out.println(layer);
			if(layer.getParentId().equals("")) {
				Category category=new Category();
				category.setCategoryId(layer.getCategoryId());
				category.addLayer(layer);
				result.put(layer.getCategoryId(), category);
			}else {
				List<String> parents=new ArrayList<String>(Arrays. asList(layer.getLineage().split("/")));
				
				Category category=result.get(parents.get(0));
				
				parents.remove(0);
				Category cate=test.getCategory(category,parents);
				System.out.println(layer);
				cate.addLayer(layer);
			}
			System.out.println(result);
		}
		 
		  ObjectMapper mapperObj = new ObjectMapper();
		  mapperObj.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
		  mapperObj.setSerializationInclusion(JsonInclude.Include.NON_NULL);
	        try {
	            String jsonResp = mapperObj.writeValueAsString(result);
	            System.out.println(jsonResp);
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
		
		 System.out.println(parse(sortedUsers));//print by name and then location
	}
	public  Category getCategory(Category cat,List<String> parents) {
		Category cate=cat;
		for(String parent:parents) {
			System.out.println(parent);
			cate=getCategory(cate, parent);
		}
		return cate;
		
		}
	public  Category getCategory(Category cat,String parent) {
		return cat.getCat(parent);
			
		}
		
	public static Map<String, List<String>> parse(List<Layer> input) {
        Map<String, List<String>> res = new HashMap<String, List<String>>();

        for(Layer s : input) {
            String [] arr = s.getLineage().split("/");
            String key = arr[0];
            String val =  s.getLineage().substring( s.getLineage().indexOf("/"));
            if(res.containsKey(key)) {
                res.get(key).add(val);
            }
            else {
                List<String> folders = new ArrayList<String>();
                folders.add(val);
                res.put(key, folders);
            }
        }
        return res;
    }
}
