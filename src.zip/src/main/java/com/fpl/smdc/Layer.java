package com.fpl.smdc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"layerName"
})
public class Layer {

@JsonProperty("layerName")
private String layerName;
@JsonProperty("category_id")
private String categoryId;
@JsonProperty("parent_id")
private String parentId;
@JsonProperty("lineage")
private String lineage;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* No args constructor for use in serialization
*
*/
public Layer() {
}

/**
*
* @param layerName
*/
public Layer(String layerName) {
super();
this.layerName = layerName;
}

public Layer(String layerName,String categoryId, String parentId) {
	super();
	this.categoryId = categoryId;
	this.parentId = parentId;

this.layerName = layerName;
}

public Layer(String layerName,String categoryId, String parentId,String lineage) {
	super();
	this.categoryId = categoryId;
	this.parentId = parentId;
this.lineage=lineage;
this.layerName = layerName;
}
@JsonProperty("layerName")
public String getLayerName() {
return layerName;
}

@JsonProperty("layerName")
public void setLayerName(String layerName) {
this.layerName = layerName;
}
@JsonProperty("lineage")
public String getLineage() {
return lineage;
}

@JsonProperty("lineage")
public void setLineage(String lineage) {
this.lineage = lineage;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

@JsonProperty("category_id")
public String getCategoryId() {
return categoryId;
}

@JsonProperty("category_id")
public void setCategoryId(String categoryId) {
this.categoryId = categoryId;
}

@JsonProperty("parent_id")
public String getParentId() {
return parentId;
}
@Override
public String toString() {
return new ToStringBuilder(this).append("layerName", layerName).append("additionalProperties", additionalProperties).toString();
}

}