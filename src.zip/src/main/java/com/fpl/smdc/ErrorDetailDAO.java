package com.fpl.smdc;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * Created by JavaDeveloperZone on 03-08-2017.
 */
@Repository
@Transactional
public interface ErrorDetailDAO extends CrudRepository<ErrorDetail,Integer> {
    List<ErrorDetail> findAll();                           // fetch all Employee
}