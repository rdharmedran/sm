package com.fpl.smdc;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"error_id",
"error_type",
"error_code",
"error_msg",
"status_type"
})
@Entity
@Table(name = "dsadmin_errors")
public class ErrorDetail {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@JsonProperty("error_id")
private Integer errorId;
@JsonProperty("error_type")
private String errorType;
@JsonProperty("error_code")
private Integer errorCode;
@JsonProperty("error_msg")
private String errorMsg;
@JsonProperty("status_type")
private String statusType;


/**
* No args constructor for use in serialization
*
*/
public ErrorDetail() {
}

/**
*
* @param statusType
* @param errorType
* @param errorCode
* @param errorId
* @param errorMsg
*/
public ErrorDetail(Integer errorId, String errorType, Integer errorCode, String errorMsg, String statusType) {
super();
this.errorId = errorId;
this.errorType = errorType;
this.errorCode = errorCode;
this.errorMsg = errorMsg;
this.statusType = statusType;
}

@JsonProperty("error_id")
public Integer getErrorId() {
return errorId;
}

@JsonProperty("error_id")
public void setErrorId(Integer errorId) {
this.errorId = errorId;
}

@JsonProperty("error_type")
public String getErrorType() {
return errorType;
}

@JsonProperty("error_type")
public void setErrorType(String errorType) {
this.errorType = errorType;
}

@JsonProperty("error_code")
public Integer getErrorCode() {
return errorCode;
}

@JsonProperty("error_code")
public void setErrorCode(Integer errorCode) {
this.errorCode = errorCode;
}

@JsonProperty("error_msg")
public String getErrorMsg() {
return errorMsg;
}

@JsonProperty("error_msg")
public void setErrorMsg(String errorMsg) {
this.errorMsg = errorMsg;
}

@JsonProperty("status_type")
public String getStatusType() {
return statusType;
}

@JsonProperty("status_type")
public void setStatusType(String statusType) {
this.statusType = statusType;
}





}
