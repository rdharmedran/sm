package com.fpl.smdc.admin.controller;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fpl.smdc.model.AuditLogRequest;

@Controller
public class LoggerController {
	private static final Logger logger = LogManager.getLogger(LoggerController.class);
	@RequestMapping(value = "/audit/log", method = RequestMethod.POST)
	 @ResponseBody
	public String showWelcomePage(@RequestBody AuditLogRequest auditLogRequest) {
		logger.info(auditLogRequest.toString());
		System.out.println("LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");
		return "success";
	}

	

}
