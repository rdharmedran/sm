package com.fpl.smdc.admin.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.fpl.smdc.log.LoginListener;
import com.fpl.smdc.log.LogoutListener;
import com.fpl.smdc.log.LogInterceptor;
import com.fpl.smdc.log.LoggingService;

;

@Configuration
public class ConfigManager implements WebMvcConfigurer {
	@Bean
	public ServletListenerRegistrationBean<HttpSessionEventPublisher> httpSessionEventPublisher() {
	    return new ServletListenerRegistrationBean<HttpSessionEventPublisher>(new HttpSessionEventPublisher());
	}
	
	 @Bean
	    public LoggingService logService(){
	        return new LoggingService();
	    }
	 @Bean
	    public LoginListener loginListener(){
	        return new LoginListener();
	    }
	 @Bean
	    public LogoutListener logoutListener(){
	        return new LogoutListener();
	    }
	 @Autowired
	    LogInterceptor logInterceptor;
	    
	    @Override
	    public void addInterceptors(InterceptorRegistry registry) {
	        registry.addInterceptor(logInterceptor);
	    }
}