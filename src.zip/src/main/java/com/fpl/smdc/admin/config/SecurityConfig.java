package com.fpl.smdc.admin.config;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;

import com.fpl.smdc.filter.AuthFilter;
import com.fpl.smdc.filter.AwsCognitoJwtAuthenticationFilter;
import com.fpl.smdc.log.LogInterceptor;

@Configuration
@EnableWebMvcSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter implements Ordered{
	
	private int order = 4;

	@Autowired
    private AwsCognitoJwtAuthenticationFilter awsCognitoJwtAuthenticationFilter;

	@Override
	public int getOrder() {
		return order;
	}

	public void setOrder(int order) {
		this.order = order;
	}
	public SecurityConfig()
	{
	super(false);
	}
	@Bean
	@Order(0)
	public RequestContextListener requestContextListener() {
	    return new RequestContextListener();
	}
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and().csrf().disable().authorizeRequests().antMatchers("/home/**").authenticated().antMatchers("/actuator/**").permitAll()
		.anyRequest().permitAll();
	      //.and().addFilterBefore(awsCognitoJwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class).oauth2Login();
				//.and().oauth2Client();
	}
//	  @Override
//	    protected void configure(final HttpSecurity http) throws Exception {
//	    	http.headers().cacheControl();
//			http.csrf().disable()
//					.authorizeRequests()
//					.antMatchers("/health").permitAll()
//					.antMatchers("/login**", "/signin/**",
//	                        "/authenticate/**", "/connect/**", "/social/authenticate").permitAll()
//					.antMatchers("/v2/**").permitAll()
//					.antMatchers("/docs/**").permitAll()
//					.antMatchers ("/api/**", "/login/**","/oauth2/**").permitAll ()
//					.antMatchers("/home/**").authenticated()
//					.antMatchers("/**").permitAll() // needs to be the last matcher, otherwise all matchers following it would never be reached
//									.anyRequest().authenticated();
//	    }
//	
	
}