package com.fpl.smdc.admin.controller;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fpl.smdc.rest.exception.AuthenticationFailed;
import com.fpl.smdc.rest.exception.InsufficientAccountPermissions;
import com.fpl.smdc.rest.exception.MissingHeaderInfoException;

import java.text.ParseException;

/**
 * User endpoints, require authentication
 */
@RestController
@RequestMapping("/layers")
public class LayerController {

    @RequestMapping(value="/list", method=RequestMethod.GET)
    @ResponseBody
    public String addUser(String chk) {
    	if(chk!=null && !chk.isEmpty()&& chk.equals("1"))
    	throw new AuthenticationFailed( "I have called");
    	else if(chk!=null && !chk.isEmpty()&& chk.equals("2"))
        	throw new InsufficientAccountPermissions( "I have called");
		return chk;
    	
    }
    
    @RequestMapping(value="/config", method=RequestMethod.GET)
    @ResponseBody
    public String config() {
return "{\n" + 
		"  \"ltd\": 28.071295553738423,\n" + 
		"  \"ltud\": -81.6558838828125,\n" + 
		"  \"default_zoom_level\": 7,\n" + 
		"  \"map_view_id\": 1,\n" + 
		"  \"map_provider_name\": \"Mapbox\",\n" + 
		"  \"map_view_name\": \"Satellite Street View\",\n" + 
		"  \"map_view_url\": \"https://{a-b}.api.mapbox.com/styles/v1/mapbox/satellite-streets-v11/tiles/256/{z}/{x}/{y}?access_token=pk.eyJ1IjoiZnBsMjAxNCIsImEiOiJPemFUMUI4In0.OR5RZQMLivbJRocqqOF-1w\",\n" + 
		"  \"is_bookmark_enabled\": \"Y\",\n" + 
		"  \"is_lasso_enabled\": \"Y\",\n" + 
		"  \"is_zoom_slider_enabled\": \"Y\",\n" + 
		"  \"is_measurement_enabled\": \"Y\",\n" + 
		"  \"is_address_serach_enabled\": \"Y\",\n" + 
		"  \"is_rotation_enabled\": \"Y\",\n" + 
		"  \"is_analysis_enabled\": \"Y\",\n" + 
		"  \"is_streetview_enabled\": \"Y\"\n" + 
		"}";
    }

}
