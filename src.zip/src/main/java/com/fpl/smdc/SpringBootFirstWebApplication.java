package com.fpl.smdc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootApplication
@ComponentScan(" com.fpl")
@EnableCaching
public class SpringBootFirstWebApplication {
    @Autowired
    private CacheManager cacheManager; 
    
	public static void main(String[] args) {
		SpringApplication.run(SpringBootFirstWebApplication.class, args);
		System.out.println("<><><<<<<<<<<<<<<<<<<<<<<<<<<<<");
	}
}
