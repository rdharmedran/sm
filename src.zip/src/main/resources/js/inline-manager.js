var constants  = {
    DATAXML : "xml",
    DATAJSON : 'json',
    CONTENTXML : 'text/xml',
    CONTENTJSON : 'application/json',
    CONTENTFORM : 'application/x-www-form-urlencoded;charset=UTF-8',
    AJAXPOST : 'POST',
    AJAXGET : 'GET',
    INSERTMODE : 'insert',
    UPDATEMODE : 'update',
    DELETEMODE : 'delete'
};
var onlineManager = (function() {
    try {
        function syncToServer(payload, url, _callback, dataType, contentType, reqType) {
            var options = {
                type: reqType,
                data: payload,
                success: ajaxsuccess,
                error: ajaxerror
            };

            if (localStorage.getItem("token")) options.headers = { 'X-ZUMO-AUTH': localStorage.getItem("token") };

            if (contentType) options.contentType = contentType;
            if (dataType) options.dataType = dataType;

            return $.ajax(url, options);

            function ajaxsuccess(data, textStatus, jqXHR) {
                _callback(data);
            }

            function ajaxerror(jqXHR, textStatus, e) {
                _callback(e);
            }
        }

        function getFromServer(url, _callback, dataType, contentType, reqType, timeout) {
            var options = {
                type: reqType,
                success: ajaxsuccess,
                error: ajaxerror
            };
            if (localStorage.getItem("token")) options.headers = { 'X-ZUMO-AUTH': localStorage.getItem("token") };
            if (contentType) options.contentType = contentType;
            if (dataType) options.dataType = dataType;
            if (timeout) options.timeout = timeout;
            try {
                return $.ajax(url, options);
            } catch (e) {
                logger.error(e);
                _callback("Error");
                error(e)
            }


            function ajaxsuccess(data, textStatus, jqXHR) {
                try {
                    _callback(data);
                } catch (e) {
                    error(e);
                }
            }

            function ajaxerror(jqXHR, textStatus, e) {
                // logger.error(e);
                _callback(e);
            }
        }

        return {
            syncToServer: syncToServer,
            getFromServer: getFromServer
        }
    } catch (e) {
        error(e)
    }

    function error(e) {
        // logger.error(e);
        // popupMessage.alert('Error processing request. please retry..', 'error');
        // loader.hide();
    }
}());