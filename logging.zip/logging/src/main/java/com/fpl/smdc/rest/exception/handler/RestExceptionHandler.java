package com.fpl.smdc.rest.exception.handler;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.fpl.smdc.rest.exception.BadRequestException;
import com.fpl.smdc.rest.exception.ForbiddenRequestException;
import com.fpl.smdc.rest.exception.InternalEeception;
import com.fpl.smdc.rest.exception.MissingHeaderInfoException;
import com.fpl.smdc.rest.exception.NeeException;
import com.fpl.smdc.rest.exception.RecordNotFoundException;
import com.fpl.smdc.rest.exception.response.ErrorResponse;
 
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler 
{
    private String INCORRECT_REQUEST = "INCORRECT_REQUEST";
    private String BAD_REQUEST = "BAD_REQUEST";
     
//    @ExceptionHandler(NeeException.class)
//    public final ResponseEntity<ErrorResponse> handleUserNotFoundException
//                        (NeeException ex, WebRequest request) 
//    {
//        List<String> details = new ArrayList<>();
//        details.add(ex.getLocalizedMessage());
//        ErrorResponse error = new ErrorResponse(400,101,ex.getClass().getSimpleName(), details,request.getContextPath());
//        System.out.println("calling it >>>>>>>>>DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDddd>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
//    }
    
    @ExceptionHandler(BadRequestException.class)
    public final ResponseEntity<ErrorResponse> handleUserNotFoundException
                        (BadRequestException ex, HttpServletRequest  request) 
    {
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        ErrorResponse error = new ErrorResponse(400,101,ex.getClass().getSimpleName(), details,request.getRequestURI());
        System.out.println("calling it >>>>>>>>>DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDddd>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
    }
    @ExceptionHandler(ForbiddenRequestException.class)
    public final ResponseEntity<ErrorResponse> handleForbiddenException
                        (ForbiddenRequestException ex, HttpServletRequest  request) 
    {
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        ErrorResponse error = new ErrorResponse(400,101,ex.getClass().getSimpleName(), details,request.getRequestURI());
        System.out.println("calling it >>>>>>>>>DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDddd>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        return new ResponseEntity<>(error, HttpStatus.FORBIDDEN);
    }
    @ExceptionHandler(InternalEeception.class)
    public final ResponseEntity<ErrorResponse> handleInternalException
                        (InternalEeception ex, HttpServletRequest  request) 
    {
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        ErrorResponse error = new ErrorResponse(400,101,ex.getClass().getSimpleName(), details,request.getRequestURI());
        System.out.println("calling it >>>>>>>>>DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDddd>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
        return new ResponseEntity<>(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(MissingHeaderInfoException.class)
    public final ResponseEntity<ErrorResponse> handleInvalidTraceIdException
                        (MissingHeaderInfoException ex, WebRequest request) {
        List<String> details = new ArrayList<>();
        details.add(ex.getLocalizedMessage());
        System.out.println("calling it >>>>>>>>>mDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDddd>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");

        ErrorResponse error = new ErrorResponse(400,101,ex.getClass().getSimpleName(), details,request.getContextPath());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }
}