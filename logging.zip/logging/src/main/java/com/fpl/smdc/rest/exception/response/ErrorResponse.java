package com.fpl.smdc.rest.exception.response;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "request_url", "status_code", "error_code", "error_msg", "error_trace" })
public class ErrorResponse {
	@JsonProperty("request_url")
	private String request_url;

	@JsonProperty("status_code")
	private Integer statusCode;

	@JsonProperty("error_code")
	private Integer errorCode;

	@JsonProperty("error_msg")
	private String errorMsg;
	@JsonProperty("error_trace")
	private List<String> errorTrace;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();
	/**
	 * No args constructor for use in serialization
	 *
	 */
	public ErrorResponse() {
	}
	/**
	 *
	 * @param details
	 * @param j
	 * @param i
	 * @param errorMsg
	 */
	public ErrorResponse(int i, int j, String errorMsg, List<String> details, String request_url) {
		super();
		this.statusCode = i;
		this.errorCode = j;
		this.errorMsg = errorMsg;
		this.errorTrace = details;
		this.request_url = request_url;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonProperty("error_code")
	public Integer getErrorCode() {
		return errorCode;
	}

	@JsonProperty("error_msg")
	public String getErrorMsg() {
		return errorMsg;
	}

	@JsonProperty("error_trace")
	public List<String> getErrorTrace() {
		return errorTrace;
	}

	public String getRequest_url() {
		return request_url;
	}

	@JsonProperty("status_code")
	public Integer getStatusCode() {
		return statusCode;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@JsonProperty("error_code")
	public void setErrorCode(Integer errorCode) {
		this.errorCode = errorCode;
	}

	@JsonProperty("error_msg")
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	@JsonProperty("error_trace")
	public void setErrorTrace(List<String> errorTrace) {
		this.errorTrace = errorTrace;
	}

	public void setRequest_url(String request_url) {
		this.request_url = request_url;
	}

	@JsonProperty("status_code")
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

}