package com.fpl.smdc.rest.exception;

public abstract class NeeException extends RuntimeException
{
    private static final long serialVersionUID = 1L;
 
    public NeeException(String message) {
        super(message);
    }
}
