package com.fpl.smdc.log;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.authentication.event.AbstractAuthenticationEvent;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.session.SessionDestroyedEvent;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.stereotype.Component;

import com.fpl.smdc.model.AuditLogRequest;

@Component
public class LoginListener implements ApplicationListener<AbstractAuthenticationEvent> {
	private static final Logger LOG = LogManager.getLogger(LoginListener.class);
	@Autowired
	LoggingService logService;

	@Value("${logservice.dashboard.id}")
	private String dashboardId;

	public void onApplicationEvent(AbstractAuthenticationEvent event) {
		AuditLogRequest logRequest = null;
		if(event.getAuthentication().getPrincipal() instanceof org.springframework.security.core.userdetails.User) {
			User ud = (User) event.getAuthentication().getPrincipal();
			 logRequest = new AuditLogRequest(dashboardId, ud.getUsername(),
					 new Date().toString(), null,null);
		}else {
		DefaultOidcUser ud = (DefaultOidcUser) event.getAuthentication().getPrincipal();
		 logRequest = new AuditLogRequest(dashboardId, ud.getEmail(),
				ud.getAuthenticatedAt().toString(), null, null);
		}
		logService.log(logRequest);
	}

}
