package com.fpl.smdc.rest.exception;

public class InvalidHeaderValue extends BadRequestException
{
    private static final long serialVersionUID = 1L;
 
    public InvalidHeaderValue(String message) {
        super(message);
    }

}
