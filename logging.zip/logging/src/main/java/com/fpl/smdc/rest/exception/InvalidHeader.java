package com.fpl.smdc.rest.exception;

public class InvalidHeader extends BadRequestException
{
    private static final long serialVersionUID = 1L;
 
    public InvalidHeader(String message) {
        super(message);
    }

}
