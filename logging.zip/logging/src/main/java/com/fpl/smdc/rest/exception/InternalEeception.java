package com.fpl.smdc.rest.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class InternalEeception  extends RuntimeException 
{
    private static final long serialVersionUID = 1L;
    public static Integer HTTP_STATUS_CODE = HttpStatus.INTERNAL_SERVER_ERROR.value();
    public InternalEeception(String message) {
        super(message);
    }
}
