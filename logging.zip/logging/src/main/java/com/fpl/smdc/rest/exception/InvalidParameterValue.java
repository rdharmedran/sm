package com.fpl.smdc.rest.exception;

public class InvalidParameterValue extends BadRequestException
{
    private static final long serialVersionUID = 1L;
 
    public InvalidParameterValue(String message) {
        super(message);
    }
}
