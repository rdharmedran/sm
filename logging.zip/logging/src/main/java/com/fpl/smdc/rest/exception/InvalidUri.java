package com.fpl.smdc.rest.exception;

public class InvalidUri extends BadRequestException
{
    private static final long serialVersionUID = 1L;
 
    public InvalidUri(String message) {
        super(message);
    }

}
