package com.fpl.smdc.rest.exception;

public class InvalidAction extends BadRequestException
{
    private static final long serialVersionUID = 1L;
 
    public InvalidAction(String message) {
        super(message);
    }
}
