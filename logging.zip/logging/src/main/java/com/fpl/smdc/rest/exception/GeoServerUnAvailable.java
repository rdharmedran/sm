package com.fpl.smdc.rest.exception;

public class GeoServerUnAvailable extends InternalEeception
{
    private static final long serialVersionUID = 1L;
 
    public GeoServerUnAvailable(String message) {
        super(message);
    }

}
