package com.fpl.smdc.log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.fpl.smdc.model.AuditLogRequest;

@Component
public class LoggingService {
	private static final Logger LOG = LogManager.getLogger(LoggingService.class);
	@Autowired
	@Qualifier("fixedThreadPool")
	private ExecutorService executorService;

	@Value("${logservice.url}")
	private String logServiceApi;

	@Value("${spring.security.oauth2.client.registration.cognito.client-id}")
	private String clientId;

	@Value("${spring.security.oauth2.client.registration.cognito.client-secret}")
	private String clientecret;
	@Value("${logservice.dashboard.id}")
	private String dashboardId;
	@Autowired
	RestTemplate restTemplate;

	public void log(AuditLogRequest msg) {

		Callable<String> callable = new Callable<String>() {
			@Override
			public String call() throws Exception {
				for (int i = 0; i < 10; i++) {
					LOG.debug(msg);
					System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + msg);
				}
				/*  */
				LinkedMultiValueMap headers = new LinkedMultiValueMap<String, String>();
				String auth = toBase64("" + clientId + ':' + clientecret);
				headers.add("HeaderName", "value");
				headers.add("Authorization", "Bearer " + msg.getClientIp());
				headers.add("Content-Type", "application/x-www-form-urlencoded");
				HttpEntity req = new HttpEntity(msg, headers);
				restTemplate.exchange(logServiceApi, HttpMethod.POST, req, String.class);

				return msg.toString();

			}
		};
		executorService.submit(callable);
	}

	@NotNull
	public static String toBase64(@NotNull String str) {
		return Base64.getEncoder().encodeToString(str.getBytes());
	}

	public void logRequest(HttpServletRequest request, Object object) {
		Callable<String> callable = new Callable<String>() {
    	    @Override
    	    public String call() throws Exception {
    	    	System.out.println("HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHIIIIIIIIIIIIIIIIIIIIIIII");
    	           for(int i=0;i<4;i++) {
    	        	   LOG.debug("{}: {} : {} : {}: {} : {}: {}: {} ", new Date(),dashboardId,request.getHeader("user-id"),
    	        			   request.getHeader("transaction_id"),request.getRequestURI(),request.getMethod(),getHeadersInfo(request),new Date());
    	        	   System.out.println(">>>>>>>>>>>>>SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS>>>>>>>>>>>>>>>>>>>>>>>>"+request);
    	           }
    	           
    	           LinkedMultiValueMap headers = new LinkedMultiValueMap<String, String>();
   				String auth = toBase64("" + clientId + ':' + clientecret);
   				headers.add("HeaderName", "value");
   				//headers.add("Authorization", "Bearer " + msg.getClientIp());
   				headers.add("Content-Type", "application/x-www-form-urlencoded");
   				HttpEntity req = new HttpEntity(request.getRequestURI(), headers);
   				AuditLogRequest reqest=new AuditLogRequest();
   				reqest.setClientIp("loc");
   				restTemplate.exchange(logServiceApi, HttpMethod.POST, req, String.class);
    	           
				return clientId;
    	         
    	        
    	    }
    	};
         executorService.submit(callable);
		
	}
	private String getHeadersInfo(HttpServletRequest request) {

       StringBuilder map = new StringBuilder();

        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            map.append("[").append(key).append(":").append(value).append("]");
        }

        return map.toString();
    }
}