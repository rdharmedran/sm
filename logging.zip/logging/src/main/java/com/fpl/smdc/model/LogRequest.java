package com.fpl.smdc.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"dasboard_id",
"user_id",
"transaction_id",
"request_URL",
"request_method",
"request_header",
"request_time",
"response_status",
"response_body",
"client_ip"
})
public class LogRequest {

@JsonProperty("dasboard_id")
private String dasboardId;
@JsonProperty("user_id")
private String userId;
@JsonProperty("transaction_id")
private String transactionId;
@JsonProperty("request_URL")
private String requestURL;
@JsonProperty("request_method")
private String requestMethod;
@JsonProperty("request_header")
private String requestHeader;
@JsonProperty("request_time")
private Integer requestTime;
@JsonProperty("response_status")
private Integer responseStatus;
@JsonProperty("response_body")
private ResponseBody responseBody;
@JsonProperty("client_ip")
private String clientIp;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* No args constructor for use in serialization
*
*/
public LogRequest() {
}

/**
*
* @param requestTime
* @param responseBody
* @param dasboardId
* @param requestURL
* @param requestMethod
* @param clientIp
* @param requestHeader
* @param responseStatus
* @param userId
* @param transactionId
*/
public LogRequest(String dasboardId, String userId, String transactionId, String requestURL, String requestMethod, String requestHeader, Integer requestTime, Integer responseStatus, ResponseBody responseBody, String clientIp) {
super();
this.dasboardId = dasboardId;
this.userId = userId;
this.transactionId = transactionId;
this.requestURL = requestURL;
this.requestMethod = requestMethod;
this.requestHeader = requestHeader;
this.requestTime = requestTime;
this.responseStatus = responseStatus;
this.responseBody = responseBody;
this.clientIp = clientIp;
}

@JsonProperty("dasboard_id")
public String getDasboardId() {
return dasboardId;
}

@JsonProperty("dasboard_id")
public void setDasboardId(String dasboardId) {
this.dasboardId = dasboardId;
}

@JsonProperty("user_id")
public String getUserId() {
return userId;
}

@JsonProperty("user_id")
public void setUserId(String userId) {
this.userId = userId;
}

@JsonProperty("transaction_id")
public String getTransactionId() {
return transactionId;
}

@JsonProperty("transaction_id")
public void setTransactionId(String transactionId) {
this.transactionId = transactionId;
}

@JsonProperty("request_URL")
public String getRequestURL() {
return requestURL;
}

@JsonProperty("request_URL")
public void setRequestURL(String requestURL) {
this.requestURL = requestURL;
}

@JsonProperty("request_method")
public String getRequestMethod() {
return requestMethod;
}

@JsonProperty("request_method")
public void setRequestMethod(String requestMethod) {
this.requestMethod = requestMethod;
}

@JsonProperty("request_header")
public String getRequestHeader() {
return requestHeader;
}

@JsonProperty("request_header")
public void setRequestHeader(String requestHeader) {
this.requestHeader = requestHeader;
}

@JsonProperty("request_time")
public Integer getRequestTime() {
return requestTime;
}

@JsonProperty("request_time")
public void setRequestTime(Integer requestTime) {
this.requestTime = requestTime;
}

@JsonProperty("response_status")
public Integer getResponseStatus() {
return responseStatus;
}

@JsonProperty("response_status")
public void setResponseStatus(Integer responseStatus) {
this.responseStatus = responseStatus;
}

@JsonProperty("response_body")
public ResponseBody getResponseBody() {
return responseBody;
}

@JsonProperty("response_body")
public void setResponseBody(ResponseBody responseBody) {
this.responseBody = responseBody;
}

@JsonProperty("client_ip")
public String getClientIp() {
return clientIp;
}

@JsonProperty("client_ip")
public void setClientIp(String clientIp) {
this.clientIp = clientIp;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}


}

