package com.fpl.smdc.config;

import org.springframework.boot.actuate.autoconfigure.web.ManagementContextConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.filter.RequestContextFilter;

@ManagementContextConfiguration
public class ManagementFilterConfiguration {

	@Bean
	public RequestContextFilter requestContextFilter() {
		return new RequestContextFilter();
	}

}