package com.fpl.smdc.model;

import io.github.millij.poi.ss.model.annotations.Sheet;
import io.github.millij.poi.ss.model.annotations.SheetColumn;

@Sheet
public class ErrorDetail {
	@SheetColumn("errorCode")
    private Integer errorCode;
   
    @SheetColumn("errorMsg")
    public String errorMsg;
    
    @SheetColumn("exceptionName")
    public String exceptionName;
    }

