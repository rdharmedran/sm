package com.fpl.smdc.config;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jose.util.DefaultResourceRetriever;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.client.token.DefaultAccessTokenRequest;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.client.RestTemplate;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Processor for AWS id token.
 */
@Configuration

public class AsyncLoggerConfig {
 
	 @Value("${cognito.rooturl}")
	    private String baseUrl;
	    @Value("${spring.security.oauth2.client.provider.cognito.authorizationUri}")
	    private String authorizeUrl;
	    @Value("${spring.security.oauth2.client.provider.cognito.tokenUri}")
	    private String tokenUrl;

	    @Value("${spring.security.oauth2.client.registration.cognito.client-id}")
	    private String clientId;

	    @Value("${spring.security.oauth2.client.registration.cognito.client-secret}")
	    private String clientecret;

	@Bean("fixedThreadPool")
	public ExecutorService fixedThreadPool() {
		return Executors.newFixedThreadPool(5);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	
	 @Bean
	    @ConfigurationProperties("spring.security.oauth2")
	    protected ClientCredentialsResourceDetails oAuthDetails() {
	        return new ClientCredentialsResourceDetails();
	    }

	    @Bean
	    protected RestTemplate restTemplate() {
	        return new RestTemplate();
	    }
}
