package com.fpl.smdc.rest;


import com.amazonaws.auth.AnonymousAWSCredentials;
import com.amazonaws.auth.BasicSessionCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidentity.AmazonCognitoIdentity;

import com.amazonaws.services.cognitoidentity.model.*;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.amazonaws.services.cognitoidp.model.*;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.*;

/**
 * The CognitoHelper class abstracts the functionality of connecting to the Cognito user pool and Federated Identities.
 */
@Component
public class CognitoHelper {
	@Value("${COGNITO.POOL.ID}")
    private String POOL_ID;
	@Value("${spring.security.oauth2.client.registration.cognito.client-id}")
    private String CLIENTAPP_ID;
	@Value("${COGNITO.POOL.ID}")
    private String FED_POOL_ID;
	@Value("${COGNITO.CUSTOMDOMAIN}")
    private String CUSTOMDOMAIN;
	@Value("${COGNITO.REGION}")
    private String REGION;
    @Value("${cognito.rooturl}")
    private String baseUrl;
    @Value("${spring.security.oauth2.client.provider.cognito.authorizationUri}")
    private String authorizeUrl;
    @Value("${spring.security.oauth2.client.provider.cognito.tokenUri}")
    private String tokenUrl;

    @Value("${spring.security.oauth2.client.registration.cognito.client-id}")
    private String clientId;

    @Value("${spring.security.oauth2.client.registration.cognito.client-secret}")
    private String clientecret;

    public CognitoHelper() {

    
    }

    String GetHostedSignInURL() {
        String customurl = "https://%s.auth.%s.amazoncognito.com/login?response_type=code&client_id=%s&redirect_uri=%s";

        return String.format(customurl, CUSTOMDOMAIN, REGION, clientId, Constants.REDIRECT_URL);
    }

    String GetTokenURL() {
        return tokenUrl;
    }

    

   
    /**
     * Helper method to validate the user
     *
     * @param username represents the username in the cognito user pool
     * @param password represents the password in the cognito user pool
     * @return returns the JWT token after the validation
     */
    public String ValidateUser(String username, String password) {
        AuthenticationHelper helper = new AuthenticationHelper(POOL_ID, CLIENTAPP_ID, "",REGION);
        return helper.PerformSRPAuthentication(username, password);
    }

   


}