package com.fpl.smdc.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"dasboard_id",
"username",
"login_time",
"logout_time",

"client_ip"
})
public class AuditLogRequest {

@JsonProperty("dasboard_id")
private String dasboardId;
@JsonProperty("username")
private String username;
@JsonProperty("login_time")
private String loginTime;
@JsonProperty("logout_time")
private String logoutTime;

@JsonProperty("client_ip")
private String clientIp;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

public AuditLogRequest() {
	
}
public AuditLogRequest(String dasboardId, String username, String loginTime, String logoutTime, String clientIp) {
super();
this.dasboardId = dasboardId;
this.username = username;
this.loginTime = loginTime;
this.logoutTime = logoutTime;

this.clientIp = clientIp;
}
@JsonProperty("dasboard_id")
public String getDasboardId() {
return dasboardId;
}

@JsonProperty("dasboard_id")
public void setDasboardId(String dasboardId) {
this.dasboardId = dasboardId;
}

@JsonProperty("username")
public String getUsername() {
return username;
}

@JsonProperty("username")
public void setUsername(String username) {
this.username = username;
}

@JsonProperty("login_time")
public String getLoginTime() {
return loginTime;
}

@JsonProperty("login_time")
public void setLoginTime(String loginTime) {
this.loginTime = loginTime;
}

@JsonProperty("logout_time")
public String getLogoutTime() {
return logoutTime;
}

@JsonProperty("logout_time")
public void setLogoutTime(String logoutTime) {
this.logoutTime = logoutTime;
}


@JsonProperty("client_ip")
public String getClientIp() {
return clientIp;
}

@JsonProperty("client_ip")
public void setClientIp(String clientIp) {
this.clientIp = clientIp;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}
@Override
public String toString() {
return new ToStringBuilder(this).append("dasboardId", dasboardId).append("username", username).append("loginTime", loginTime)
		.append("logoutTime", logoutTime).append("clientIp", clientIp).append("additionalProperties", additionalProperties).toString();
}
}