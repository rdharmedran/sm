package com.fpl.smdc.rest.exception;

public class OperationTimedOut extends InternalEeception
{
    private static final long serialVersionUID = 1L;
 
    public OperationTimedOut(String message) {
        super(message);
    }

}
