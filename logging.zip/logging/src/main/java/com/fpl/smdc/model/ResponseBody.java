package com.fpl.smdc.model;


import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"error_code",
"error_message"
})
public class ResponseBody {

@JsonProperty("error_code")
private Integer errorCode;
@JsonProperty("error_message")
private String errorMessage;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* No args constructor for use in serialization
*
*/
public ResponseBody() {
}

/**
*
* @param errorMessage
* @param errorCode
*/
public ResponseBody(Integer errorCode, String errorMessage) {
super();
this.errorCode = errorCode;
this.errorMessage = errorMessage;
}

@JsonProperty("error_code")
public Integer getErrorCode() {
return errorCode;
}

@JsonProperty("error_code")
public void setErrorCode(Integer errorCode) {
this.errorCode = errorCode;
}

@JsonProperty("error_message")
public String getErrorMessage() {
return errorMessage;
}

@JsonProperty("error_message")
public void setErrorMessage(String errorMessage) {
this.errorMessage = errorMessage;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}



}