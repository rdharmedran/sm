package com.fpl.smdc.rest.exception;

public class InvalidAuthenticationInfo extends BadRequestException
{
    private static final long serialVersionUID = 1L;
 
    public InvalidAuthenticationInfo(String message) {
        super(message);
    }
}
