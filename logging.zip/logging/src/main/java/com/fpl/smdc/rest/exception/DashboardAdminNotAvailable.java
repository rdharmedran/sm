package com.fpl.smdc.rest.exception;

public class DashboardAdminNotAvailable extends InternalEeception
{
    private static final long serialVersionUID = 1L;
 
    public DashboardAdminNotAvailable(String message) {
        super(message);
    }
}
