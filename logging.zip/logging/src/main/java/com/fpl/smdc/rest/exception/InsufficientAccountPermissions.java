package com.fpl.smdc.rest.exception;

public class InsufficientAccountPermissions extends ForbiddenRequestException
{
    private static final long serialVersionUID = 1L;
 
    public InsufficientAccountPermissions(String message) {
        super(message);
    }

}
