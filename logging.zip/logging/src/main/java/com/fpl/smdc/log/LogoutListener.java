package com.fpl.smdc.log;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.session.SessionDestroyedEvent;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.stereotype.Component;

import com.fpl.smdc.model.AuditLogRequest;

@Component
public class LogoutListener implements ApplicationListener<SessionDestroyedEvent> {
	private static final Logger LOG = LogManager.getLogger(LogoutListener.class);
	@Value("${logservice.dashboard.id}")
	private String dashboardId;

	@Autowired
	LoggingService logService;

	@Override
	public void onApplicationEvent(SessionDestroyedEvent event) {
		List<SecurityContext> lstSecurityContext = event.getSecurityContexts();
		@SuppressWarnings("unused")
		AuditLogRequest logRequest = null;

		for (SecurityContext securityContext : lstSecurityContext) {

			if (securityContext.getAuthentication()
					.getPrincipal() instanceof org.springframework.security.core.userdetails.User) {
				User ud = (User) securityContext.getAuthentication().getPrincipal();
				logRequest = new AuditLogRequest(dashboardId, ud.getUsername(), null, new Date().toString(), null);
			} else {
				DefaultOidcUser ud = (DefaultOidcUser) securityContext.getAuthentication().getPrincipal();
				logRequest = new AuditLogRequest(dashboardId, ud.getEmail(), null, new Date().toString(), null);
			}

			logService.log(logRequest);
		}
	}

}