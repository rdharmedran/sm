package com.fpl.smdc.rest.exception;

public class AuthenticationFailed extends BadRequestException
{
    private static final long serialVersionUID = 1L;
 
    public AuthenticationFailed(String message) {
        super(message);
    }

}
