package com.in28minutes.springboot.web;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.fpl.smdc.rest.handler.HttpClientConfig;
import com.fpl.smdc.rest.handler.RestTemplateConfig;
 

 
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { RestTemplateConfig.class, HttpClientConfig.class })
public class TestApplication {
 
    @Autowired
    RestTemplate restTemplate;
 
    @Test
    public void getEmployees() {
        final String uri = "https://localhost:8443/layers/list";
 
        String result = restTemplate.getForObject(uri, String.class);
 System.out.println("FFFFFFFFF"+result);
        Assert.assertEquals(true, result.indexOf("Lokesh") > 0);
    }
}
