package com.zebra.reciept.converter;
import org.apache.avro.Schema;
import org.apache.avro.Schema.Field;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.generic.GenericRecordBuilder;
import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.SimpleFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.auto.value.AutoValue;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import com.zebra.reciept.StarterPipeline;
import com.zebra.reciept.model.v7.RecieptDocument;

import java.nio.charset.StandardCharsets;
import javax.annotation.Nullable;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.PipelineResult;
import org.apache.beam.sdk.coders.CoderRegistry;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessageWithAttributesCoder;
import org.apache.beam.sdk.io.mongodb.MongoDbIO;
import org.apache.beam.sdk.metrics.Counter;
import org.apache.beam.sdk.metrics.Metrics;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.options.Validation;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TupleTagList;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.base.Throwables;
import org.bson.Document;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.joda.time.MutableDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
	public class RecieptToGenericRecordFn extends DoFn<RecieptDocument, GenericRecord> {
		
		private static final Logger Log = LoggerFactory.getLogger(RecieptToGenericRecordFn.class);
		@ProcessElement
		public void processElement(ProcessContext c) {
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>eeeee>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			Log.info("Start convert:"+c.element().toString());
			System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
			Schema schema = RecieptDocument.getClassSchema();
			GenericRecordBuilder builder=new GenericRecordBuilder(schema);
			RecieptDocument e = c.element();
			
			for(Field f : schema.getFields())
			{
				try {
				System.out.println("TYpe is:"+(e.get(f.name())!=null?e.get(f.name()).getClass()!=null?e.get(f.name()).getClass().getName():0:0)+"Field is:"+f.name()+"Value is>>>>"+e.get(f.name()));
				}catch(Exception ex) {
					
				}
				if(e.get(f.name()) instanceof org.joda.time.LocalDate)
				{
					DateTime dt = ((LocalDate)e.get(f.name())).toDateTimeAtCurrentTime(DateTimeZone.UTC);
					MutableDateTime epoch = new MutableDateTime(0l, DateTimeZone.UTC);
					Days days = Days.daysBetween(epoch, dt);
					builder.set(f.name(), days.getDays());
				}
				else
					builder.set(f.name(), e.get(f.name()));
			}
			
			c.output(builder.build());
		}
	}