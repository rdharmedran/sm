package com.fpl.smdc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder({
"category_id",
"parent_id",
"Layers"
})
public class Category {

@JsonProperty("category_id")
private String categoryId;
@JsonProperty("parent_id")
private String parentId;
@JsonProperty("Layers")
private List<Layer> layers = new ArrayList<Layer>();
@JsonProperty("Map")
private Map<String,Category> cate = new HashMap<>();
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

/**
* No args constructor for use in serialization
*
*/
public Category() {
}

/**
*
* @param layers
* @param categoryId
* @param parentId
*/
public Category(String categoryId, String parentId, List<Layer> layers) {
super();
this.categoryId = categoryId;
this.parentId = parentId;
//this.layers = layers;
}

@JsonProperty("category_id")
public String getCategoryId() {
return categoryId;
}



public void addLayer(Layer layer) {
	System.out.println("Adding>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
 layers.add(layer);
	System.out.println("Adding>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+layer);

}
public void addCat(String id,Category cat) {
	cate.put(id,cat);
	}
public Category getCat(String id) {
	if(cate.get(id)==null) {
		Category category=new Category();
		category.setCategoryId(id);
		addCat( id, category);
	}
	return cate.get(id);
	}
@JsonProperty("category_id")
public void setCategoryId(String categoryId) {
this.categoryId = categoryId;
}

@JsonProperty("parent_id")
public String getParentId() {
return parentId;
}

@JsonProperty("parent_id")
public void setParentId(String parentId) {
this.parentId = parentId;
}

@JsonProperty("Layers")
public List<Layer> getLayers() {
return layers;
}

@JsonProperty("Layers")
public void setLayers(List<Layer> layers) {
this.layers = layers;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

@Override
public String toString() {
return new ToStringBuilder(this).append("categoryId", categoryId).append("cate", cate).append("layers", layers).append("additionalProperties", additionalProperties).toString();
}

}