package com.fpl.smdc.admin.config;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.SimpleTimeZone;

import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.ShortBufferException;
import javax.crypto.spec.SecretKeySpec;
import javax.validation.constraints.NotNull;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.apache.commons.codec.digest.HmacAlgorithms;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.AnonymousAWSCredentials;
import com.amazonaws.http.AmazonHttpClient;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProvider;
import com.amazonaws.services.cognitoidp.AWSCognitoIdentityProviderClientBuilder;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.AdminInitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.AuthFlowType;
import com.amazonaws.services.cognitoidp.model.ChallengeNameType;
import com.amazonaws.services.cognitoidp.model.InitiateAuthRequest;
import com.amazonaws.services.cognitoidp.model.InitiateAuthResult;
import com.amazonaws.services.cognitoidp.model.RespondToAuthChallengeRequest;
import com.amazonaws.services.cognitoidp.model.RespondToAuthChallengeResult;
import com.amazonaws.services.cognitoidp.model.UserNotFoundException;
import com.amazonaws.util.StringUtils;

import com.fpl.smdc.rest.CognitoJWTParser;

/**
 * A Spring Security AuthentictionProvider based on an AWS Cognito User Pool.
 * 
 * Use of this AuthenticationProvider requires an AWS Account, Access Key, Secret Key.
 * The AK / SK is obtained by the local ~/.aws/credentials file when running outside of AWS, 
 * or obtained automatically by IAM Role when running on AWS.  Selected region is obtained
 * from the ~/.aws/config file when running outside of AWS, or obtained automatically via 
 * instance metadata when running on AWS.
 * 
 * A Cognito user pool must be established.  This will hold all users / credentials.  The pool
 * is identified to this code via PoolID.  Additionally, the pool must have a "client app" defined
 * for it which represents this application.  The ClientID and Client Secret identify this "app". 
 * These values should not be confused with the general IAM Access Key / Secret Key.
 * 
 * 
 */
@Component("cognitoProvider")
public class CognitoAuthenticationProvider implements AuthenticationProvider {

	@Value("${COGNITO.POOL.ID}")
	private String poolId;
	
	@Value("${cognito.client-id2}")
	private String clientId;
	
//	@Value("${spring.security.oauth2.client.registration.cognito.client-secret}")
	private String clientSecret="";
	  private static final String HEX_N =
	            "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD1"
	                    + "29024E088A67CC74020BBEA63B139B22514A08798E3404DD"
	                    + "EF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245"
	                    + "E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED"
	                    + "EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3D"
	                    + "C2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F"
	                    + "83655D23DCA3AD961C62F356208552BB9ED529077096966D"
	                    + "670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B"
	                    + "E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9"
	                    + "DE2BCBF6955817183995497CEA956AE515D2261898FA0510"
	                    + "15728E5A8AAAC42DAD33170D04507A33A85521ABDF1CBA64"
	                    + "ECFB850458DBEF0A8AEA71575D060C7DB3970F85A6E1E4C7"
	                    + "ABF5AE8CDB0933D71E8C94E04A25619DCEE3D2261AD2EE6B"
	                    + "F12FFA06D98A0864D87602733EC86A64521F2B18177B200C"
	                    + "BBE117577A615D6C770988C0BAD946E208E24FA074E5AB31"
	                    + "43DB5BFCE0FD108E4B82D120A93AD2CAFFFFFFFFFFFFFFFF";
	    private static final BigInteger N = new BigInteger(HEX_N, 16);
	    private static final BigInteger g = BigInteger.valueOf(2);
	    private static final BigInteger k;
	    private static final int EPHEMERAL_KEY_LENGTH = 1024;
	    private static final int DERIVED_KEY_SIZE = 16;
	    private static final String DERIVED_KEY_INFO = "Caldera Derived Key";
	    private static final ThreadLocal<MessageDigest> THREAD_MESSAGE_DIGEST =
	            new ThreadLocal<MessageDigest>() {
	                @Override
	                protected MessageDigest initialValue() {
	                    try {
	                        return MessageDigest.getInstance("SHA-256");
	                    } catch (NoSuchAlgorithmException e) {
	                        throw new SecurityException("Exception in authentication", e);
	                    }
	                }
	            };
	    private static final SecureRandom SECURE_RANDOM;
	    private static BigInteger a;
	    private static BigInteger A;
	    static {
	        try {
	            SECURE_RANDOM = SecureRandom.getInstance("SHA1PRNG");

	            MessageDigest messageDigest = THREAD_MESSAGE_DIGEST.get();
	            messageDigest.reset();
	            messageDigest.update(N.toByteArray());
	            byte[] digest = messageDigest.digest(g.toByteArray());
	            k = new BigInteger(1, digest);
	        } catch (NoSuchAlgorithmException e) {
	            throw new SecurityException(e.getMessage(), e);
	        }
	        
	        do {
	              a = new BigInteger(EPHEMERAL_KEY_LENGTH, SECURE_RANDOM).mod(N);
	              A = g.modPow(a, N);
	          } while (A.mod(N).equals(BigInteger.ZERO));
	    }

	  
	    
	    public  CognitoAuthenticationProvider() {
	    	  do {
	              a = new BigInteger(EPHEMERAL_KEY_LENGTH, SECURE_RANDOM).mod(N);
	              A = g.modPow(a, N);
	          } while (A.mod(N).equals(BigInteger.ZERO));
	    }
	    private BigInteger getA() {
	        return A;
	    }
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
System.out.println("NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN");
		//	This is the username and password 
		//	obtained from Spring's authentication manager 
		//	(ultimately the login page):
		String userId = authentication.getName();
		String password = authentication.getCredentials().toString();

		Map<String, String> params = new HashMap<>();
		params.put("USERNAME", userId);
		params.put("SECRET_HASH", calculateSecretHash(userId));
		params.put("PASSWORD", password);
		
		InitiateAuthRequest initiateAuthRequest = new InitiateAuthRequest();
        initiateAuthRequest.setAuthFlow(AuthFlowType.USER_SRP_AUTH);
        initiateAuthRequest.setClientId(this.clientId);
        //Only to be used if the pool contains the secret key.
        initiateAuthRequest.addAuthParametersEntry("SECRET_HASH", this.calculateSecretHash(this.clientId,this.clientSecret,userId));
        initiateAuthRequest.addAuthParametersEntry("USERNAME", userId);
        initiateAuthRequest.addAuthParametersEntry("PASSWORD", password);
       // initiateAuthRequest.addAuthParametersEntry("SECRET_HASH", calculateSecretHash(userId));
        initiateAuthRequest.addAuthParametersEntry("SRP_A", this.getA().toString(16));

		//	Make a Cognito Identity Provider client.  This will default to use the ACCESS_KEY and SECRET_ACCESS_KEY 
		//	associated with the local machine, or the SDK will use the instance's role to obtain one from STS.
		AWSCognitoIdentityProvider identityProvider = 
				AWSCognitoIdentityProviderClientBuilder.standard() .withRegion(Regions.US_EAST_1).build();
			
		//	Make the login request to Cognito.  AWS documentation says this 
		//	requires "admin credentials", but this is incorrect; one only needs cognito permissions:
		AdminInitiateAuthResult result = null;
		InitiateAuthResult initiateAuthResult =null;
		try {
			
			  initiateAuthResult = identityProvider.initiateAuth(initiateAuthRequest);
				
					
		} catch(UserNotFoundException notfound) {
			//	If we get a user not found error from AWS Cognito, translate this into a Spring Security user not found error.
			//	this will allow the framework to handle the situation gently (take us back to the login page) 
			//	rather than an unknown general error:
			throw new UsernameNotFoundException(notfound.getErrorMessage(),notfound);
		}
		
		
		//	Let's ignore new password stuff for now:
		if(initiateAuthResult.getChallengeName().equals("NEW_PASSWORD_REQUIRED")) {
			// ignore
		}

		//	This token will be stored by Spring Security 
		//	to represent this authenticated entity going forward:
		return new UsernamePasswordAuthenticationToken(
    		userId, password, new ArrayList<>());
	}
	
	public Authentication authenticate() throws AuthenticationException {
System.out.println("NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNuuuuuuuuuuuuuuuuuuuuuu");
		//	This is the username and password 
		//	obtained from Spring's authentication manager 
		//	(ultimately the login page):
String userId ="r.dharmendran@gmail.com";
		String password = "kRdmani-7";

	
		InitiateAuthRequest initiateAuthRequest = new InitiateAuthRequest();
		initiateAuthRequest.setAuthFlow(AuthFlowType.USER_SRP_AUTH);
		initiateAuthRequest.setClientId(this.clientId);
		//Only to be used if the pool contains the secret key.
       // initiateAuthRequest.addAuthParametersEntry("SECRET_HASH", this.calculateSecretHash(userId));
		initiateAuthRequest.addAuthParametersEntry("USERNAME", userId);
		//initiateAuthRequest.addAuthParametersEntry("PASSWORD", password);
		//initiateAuthRequest.addAuthParametersEntry("SECRET_HASH",null);
		System.out.println(this.clientId+"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"+this.clientSecret);
		 AnonymousAWSCredentials awsCreds = new AnonymousAWSCredentials();
		  initiateAuthRequest.addAuthParametersEntry("SRP_A", A.toString(16));
//			Make a Cognito Identity Provider client.  This will default to use the ACCESS_KEY and SECRET_ACCESS_KEY 
//			associated with the local machine, or the SDK will use the instance's role to obtain one from STS.
		  AWSCognitoIdentityProvider identityProvider = AWSCognitoIdentityProviderClientBuilder
                  .standard()
                  .withCredentials(new AWSStaticCredentialsProvider(awsCreds))
                  .withRegion(Regions.US_EAST_1)
                  .build();
			
//			Make the login request to Cognito.  AWS documentation says this 
//			requires "admin credentials", but this is incorrect; one only needs cognito permissions:
		  String authresult = null;
		InitiateAuthResult initiateAuthResult =null;
		//  String authresult
		try {
			AmazonHttpClient d=null;
			  initiateAuthResult = identityProvider.initiateAuth(initiateAuthRequest);
			  System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+initiateAuthResult.getChallengeName());
			//  System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+initiateAuthResult.getAuthenticationResult().getAccessToken());
			  if (ChallengeNameType.PASSWORD_VERIFIER.toString().equals(initiateAuthResult.getChallengeName())) {
	                RespondToAuthChallengeRequest challengeRequest = userSrpAuthRequest(initiateAuthResult, password,initiateAuthRequest.getAuthParameters().get("SECRET_HASH"));
	                RespondToAuthChallengeResult result = identityProvider.respondToAuthChallenge(challengeRequest);
	                System.out.println("LLLLLLLLLLLLLLLLLLL"+result);
	                System.out.println(CognitoJWTParser.getPayload(result.getAuthenticationResult().getIdToken()));
	                 authresult = result.getAuthenticationResult().getIdToken();
	                 System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+authresult);
	            }
					
		} catch(UserNotFoundException notfound) {
			notfound.printStackTrace();
			//	If we get a user not found error from AWS Cognito, translate this into a Spring Security user not found error.
			//	this will allow the framework to handle the situation gently (take us back to the login page) 
			//	rather than an unknown general error:
			throw new UsernameNotFoundException(notfound.getErrorMessage(),notfound);
		}
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"+A);

//			Let's ignore new password stuff for now:
		if(initiateAuthResult.getChallengeName().equals("NEW_PASSWORD_REQUIRED")) {
			// ignore
		}



				//	This token will be stored by Spring Security 
				//	to represent this authenticated entity going forward:
				return new UsernamePasswordAuthenticationToken(
		    		userId, password, new ArrayList<>());
	}
	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}
	
	 private byte[] getPasswordAuthenticationKey(String userId,
             String userPassword,
             BigInteger B,
             BigInteger salt) {
// Authenticate the password
// u = H(A, B)
MessageDigest messageDigest = THREAD_MESSAGE_DIGEST.get();
messageDigest.reset();
messageDigest.update(A.toByteArray());
BigInteger u = new BigInteger(1, messageDigest.digest(B.toByteArray()));
if (u.equals(BigInteger.ZERO)) {
throw new SecurityException("Hash of A and B cannot be zero");
}

// x = H(salt | H(poolName | userId | ":" | password))
messageDigest.reset();
messageDigest.update(this.poolId.split("_", 2)[1].getBytes(StringUtils.UTF8));
messageDigest.update(userId.getBytes(StringUtils.UTF8));
messageDigest.update(":".getBytes(StringUtils.UTF8));
byte[] userIdHash = messageDigest.digest(userPassword.getBytes(StringUtils.UTF8));

messageDigest.reset();
messageDigest.update(salt.toByteArray());
BigInteger x = new BigInteger(1, messageDigest.digest(userIdHash));
BigInteger S = (B.subtract(k.multiply(g.modPow(x, N))).modPow(a.add(u.multiply(x)), N)).mod(N);

Hkdf hkdf;
try {
hkdf = Hkdf.getInstance("HmacSHA256");
} catch (NoSuchAlgorithmException e) {
throw new SecurityException(e.getMessage(), e);
}
hkdf.init(S.toByteArray(), u.toByteArray());
byte[] key = hkdf.deriveKey(DERIVED_KEY_INFO, DERIVED_KEY_SIZE);
System.out.println("KEYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY"+new String(key));
return key;
}

	 private RespondToAuthChallengeRequest userSrpAuthRequest(InitiateAuthResult challenge,
             String password, String secretHash
) {
		 System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>FFFFFFFFFFFFFFFFFFFFFF");
String userIdForSRP = challenge.getChallengeParameters().get("USER_ID_FOR_SRP");
String usernameInternal =  "r.dharmendran@gmail.com";
System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>FFFFFFFFFFFFFFFFFFFFFF"+usernameInternal);
System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>FFFFFFFFFFFFFFFFFFFFFF"+userIdForSRP);
BigInteger B = new BigInteger(challenge.getChallengeParameters().get("SRP_B"), 16);
if (B.mod(N).equals(BigInteger.ZERO)) {
throw new SecurityException("SRP error, B cannot be zero");
}

BigInteger salt = new BigInteger(challenge.getChallengeParameters().get("SALT"), 16);

try {
	 byte[] key = getPasswordAuthenticationKey(userIdForSRP, password, B, salt);


Date timestamp = new Date();
byte[] hmac = null;

Mac mac = Mac.getInstance("HmacSHA256");
SecretKeySpec keySpec = new SecretKeySpec(key, "HmacSHA256");
mac.init(keySpec);
mac.update(this.poolId.split("_", 2)[1].getBytes(StringUtils.UTF8));
mac.update(userIdForSRP.getBytes(StringUtils.UTF8));
byte[] secretBlock = Base64.getEncoder().encode(challenge.getChallengeParameters().get("SECRET_BLOCK").getBytes());
mac.update(secretBlock);
SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy", Locale.US);
simpleDateFormat.setTimeZone(new SimpleTimeZone(SimpleTimeZone.UTC_TIME, "UTC"));
String dateString = simpleDateFormat.format(timestamp);
byte[] dateBytes = dateString.getBytes(StringUtils.UTF8);
hmac = mac.doFinal(dateBytes);

SimpleDateFormat formatTimestamp = new SimpleDateFormat("EEE MMM d HH:mm:ss z yyyy", Locale.US);
formatTimestamp.setTimeZone(new SimpleTimeZone(SimpleTimeZone.UTC_TIME, "UTC"));

Map<String, String> srpAuthResponses = new HashMap<>();
srpAuthResponses.put("PASSWORD_CLAIM_SECRET_BLOCK", challenge.getChallengeParameters().get("SECRET_BLOCK"));
srpAuthResponses.put("PASSWORD_CLAIM_SIGNATURE", new String(Base64.getEncoder().encode(hmac), StringUtils.UTF8));
srpAuthResponses.put("TIMESTAMP", formatTimestamp.format(timestamp));
srpAuthResponses.put("USERNAME", usernameInternal);
if (secretHash != null && !secretHash.isEmpty()) {
    srpAuthResponses.put("SECRET_HASH", secretHash);
}
RespondToAuthChallengeRequest authChallengeRequest = new RespondToAuthChallengeRequest();
authChallengeRequest.setChallengeName(challenge.getChallengeName());
authChallengeRequest.setClientId(clientId);
authChallengeRequest.setSession(challenge.getSession());
authChallengeRequest.setChallengeResponses(srpAuthResponses);
return authChallengeRequest;
} catch (Exception e) {
System.out.println(e);
}

return null;
}


	  
	 public  String calculateSecretHash(String userPoolClientId, String userPoolClientSecret, String userName) {
	     final String HMAC_SHA256_ALGORITHM = "HmacSHA256";
	     
	     SecretKeySpec signingKey = new SecretKeySpec(
	             userPoolClientSecret.getBytes(StandardCharsets.UTF_8),
	             HMAC_SHA256_ALGORITHM);
	     try {
	         Mac mac = Mac.getInstance(HMAC_SHA256_ALGORITHM);
	         mac.init(signingKey);
	         mac.update(userName.getBytes(StandardCharsets.UTF_8));
	         byte[] rawHmac = mac.doFinal(userPoolClientId.getBytes(StandardCharsets.UTF_8));
	         return Base64.getEncoder().encodeToString(rawHmac);
	     } catch (Exception e) {
	         throw new RuntimeException("Error while calculating ");
	     }
	 }
	//	This code is using the clientSecret to somehow hash/sign the provided username.
	//	I'm not really sure why this needs to be done, I guess it just proves we posess the client secret.
	private String calculateSecretHash(@NotNull String userName) {

		SecretKeySpec signingKey = 
			new SecretKeySpec(
				clientSecret.getBytes(StandardCharsets.UTF_8),
				HmacAlgorithms.HMAC_SHA_256.toString());

		try {
			Mac mac = Mac.getInstance(HmacAlgorithms.HMAC_SHA_256.toString());
			mac.init(signingKey);
			mac.update(userName.getBytes(StandardCharsets.UTF_8));
			byte[] rawHmac = mac.doFinal(clientId.getBytes(StandardCharsets.UTF_8));
			return Base64.getEncoder().encodeToString(rawHmac);

		} catch (Exception ex) {
			throw new RuntimeException("Error calculating secret hash", ex);
		}
	}
	 /**
     * Internal class for doing the Hkdf calculations.
     */
    final static class Hkdf {
        private static final int MAX_KEY_SIZE = 255;
        private final byte[] EMPTY_ARRAY = new byte[0];
        private final String algorithm;
        private SecretKey prk = null;


        /**
         * @param algorithm REQUIRED: The type of HMAC algorithm to be used.
         */
        private Hkdf(String algorithm) {
            if (!algorithm.startsWith("Hmac")) {
                throw new IllegalArgumentException("Invalid algorithm " + algorithm
                        + ". Hkdf may only be used with Hmac algorithms.");
            } else {
                this.algorithm = algorithm;
            }
        }

        private static Hkdf getInstance(String algorithm) throws NoSuchAlgorithmException {

            return new Hkdf(algorithm);
        }

        /**
         * @param ikm REQUIRED: The input key material.
         */
        public void init(byte[] ikm) {
            this.init(ikm, (byte[]) null);
        }

        /**
         * @param ikm  REQUIRED: The input key material.
         * @param salt REQUIRED: Random bytes for salt.
         */
        private void init(byte[] ikm, byte[] salt) {
            byte[] realSalt = salt == null ? EMPTY_ARRAY : (byte[]) salt.clone();
            byte[] rawKeyMaterial = EMPTY_ARRAY;

            try {
                final Mac e = Mac.getInstance(this.algorithm);
                if (realSalt.length == 0) {
                    realSalt = new byte[e.getMacLength()];
                    Arrays.fill(realSalt, (byte) 0);
                }

                e.init(new SecretKeySpec(realSalt, this.algorithm));
                rawKeyMaterial = e.doFinal(ikm);
                final SecretKeySpec key = new SecretKeySpec(rawKeyMaterial, this.algorithm);
                Arrays.fill(rawKeyMaterial, (byte) 0);
                this.unsafeInitWithoutKeyExtraction(key);
            } catch (final GeneralSecurityException var10) {
                throw new RuntimeException("Unexpected exception", var10);
            } finally {
                Arrays.fill(rawKeyMaterial, (byte) 0);
            }

        }

        /**
         * @param rawKey REQUIRED: Current secret key.
         * @throws InvalidKeyException
         */
        private void unsafeInitWithoutKeyExtraction(SecretKey rawKey) throws InvalidKeyException {
            if (!rawKey.getAlgorithm().equals(this.algorithm)) {
                throw new InvalidKeyException(
                        "Algorithm for the provided key must match the algorithm for this Hkdf. Expected "
                                + this.algorithm + " but found " + rawKey.getAlgorithm());
            } else {
                this.prk = rawKey;
            }
        }

        /**
         * @param info   REQUIRED
         * @param length REQUIRED
         * @return converted bytes.
         */
        private byte[] deriveKey(String info, int length) {
            return this.deriveKey(info != null ? info.getBytes(StringUtils.UTF8) : null, length);
        }

        /**
         * @param info   REQUIRED
         * @param length REQUIRED
         * @return converted bytes.
         */
        private byte[] deriveKey(byte[] info, int length) {
            final byte[] result = new byte[length];

            try {
                this.deriveKey(info, length, result, 0);
                return result;
            } catch (final ShortBufferException var5) {
                throw new RuntimeException(var5);
            }
        }

        /**
         * @param info   REQUIRED
         * @param length REQUIRED
         * @param output REQUIRED
         * @param offset REQUIRED
         * @throws ShortBufferException
         */
        private void deriveKey(byte[] info, int length, byte[] output, int offset)
                throws ShortBufferException {
            this.assertInitialized();
            if (length < 0) {
                throw new IllegalArgumentException("Length must be a non-negative value.");
            } else if (output.length < offset + length) {
                throw new ShortBufferException();
            } else {
                final Mac mac = this.createMac();
                if (length > MAX_KEY_SIZE * mac.getMacLength()) {
                    throw new IllegalArgumentException(
                            "Requested keys may not be longer than 255 times the underlying HMAC length.");
                } else {
                    byte[] t = EMPTY_ARRAY;

                    try {
                        int loc = 0;

                        for (byte i = 1; loc < length; ++i) {
                            mac.update(t);
                            mac.update(info);
                            mac.update(i);
                            t = mac.doFinal();

                            for (int x = 0; x < t.length && loc < length; ++loc) {
                                output[loc] = t[x];
                                ++x;
                            }
                        }
                    } finally {
                        Arrays.fill(t, (byte) 0);
                    }

                }
            }
        }

        /**
         * @return the generates message authentication code.
         */
        private Mac createMac() {
            try {
                final Mac ex = Mac.getInstance(this.algorithm);
                ex.init(this.prk);
                return ex;
            } catch (final NoSuchAlgorithmException var2) {
                throw new RuntimeException(var2);
            } catch (final InvalidKeyException var3) {
                throw new RuntimeException(var3);
            }
        }

        /**
         * Checks for a valid pseudo-random key.
         */
        private void assertInitialized() {
            if (this.prk == null) {
                throw new IllegalStateException("Hkdf has not been initialized");
            }
        }
    }
}