package com.fpl.smdc.admin.controller;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.authentication.OAuth2AuthenticationToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fpl.smdc.admin.config.AuthenticationHelper1;
import com.fpl.smdc.admin.config.CognitoAuthenticationProvider;
import com.fpl.smdc.rest.*;
@Controller
public class WelcomeController {
	private static final Logger logger = LogManager.getLogger(WelcomeController.class);

	
	@Autowired
	private CognitoAuthenticationProvider provider;
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String showWelcomePage(ModelMap model) {
		
		System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU");
		//final OAuth2AuthenticationDetails details = (OAuth2AuthenticationDetails) auth.
	    //token
	  //  String accessToken = details.getTokenValue();
	    //reference
	  //  final OAuth2AccessToken accessToken1 = tokenStore.readAccessToken(details.getTokenValue());
		AuthenticationHelper1 helper=new AuthenticationHelper1("us-east-1_EWOdBkkDp","5fadq24q39emoinqkaj2uoiv7h",null,"us-east-1");
		logger.debug(helper.PerformSRPAuthentication("r.dharmendran@gmail.com", "kRdmani-7"));
		//logger.debug(provider.authenticate());
		logger.info("Info log");
		logger.warn("Hey, This is a warning!");
		logger.error("Oops! We have an Error. OK");
		logger.fatal("Damn! Fatal error. Please fix me.");
		System.out.println("llllllllllllllllllll");
		model.put("name", "smdc USER");
		return "welcome";
	}

	

}
