var layerDataManager = (function() {
    'use strict';
    try {
        function getLayerMetadata(_callback) {
           // var url = appUtils.baseWebAPI + "/getLayerInfo";
            var url='http://localhost:9000/layers/list';
            return onlineManager.getFromServer(url, _callback, constants.DATAJSON, constants.CONTENTJSON, constants.AJAXGET);
        }


        function createTileWMSLayer(lyrObj, lyrUrl) {

            return new ol.layer.Tile({
                id: lyrObj.id,
                title: lyrObj.label,
                source: new ol.source.TileWMS({
                    //crossOrigin: 'anonymous',
                    url: appUtils.geoUrl,
                    params: { 'LAYERS': lyrObj.name, 'TILED': true },
                    serverType: 'geoserver',
                }),
                visible: lyrObj.isvisible,
                // maxResolution: lyrObj.maxscale,
                // minResolution: lyrObj.minscale
            });
        }

        function createTileWMTSLayer(lyrObj, lyrUrl) {

            var projection = ol.proj.get('EPSG:3857');
            // var meter = ['smdc:meters_region1', 'smdc:meters_region2'];
            var projectionExtent = projection.getExtent();
            var size = ol.extent.getWidth(projectionExtent) / 256;
            var resolutions = new Array(appUtils.mapMaxZoom + 1);
            var matrixIds = new Array(appUtils.mapMaxZoom + 1);
            for (var z = 0; z < appUtils.mapMaxZoom + 1; ++z) {
                resolutions[z] = size / Math.pow(2, z);
                // matrixIds[z] = 'EPSG:90091:' + z;
                matrixIds[z] = 'EPSG:3857:' + z;
            }

            var layerSource = new ol.source.WMTS({
                url: lyrUrl,            
                layer: lyrObj.name,
                matrixSet: 'EPSG:3857',
                format: 'image/png',
                projection: projection,
                tileGrid: new ol.tilegrid.WMTS({
                    origin: ol.extent.getTopLeft(projectionExtent),
                    resolutions: resolutions,
                    matrixIds: matrixIds
                }),
                style: '',
                wrapX: true,
                crossOrigin: 'anonymous',
                t: Date.now(),
            });

            return new ol.layer.Tile({
                id: 123,

                title: 'WMTS layer',
                source: layerSource,
                visible: true,
                // maxResolution: lyrObj.maxscale,
                // minResolution: lyrObj.minscale
            });


        }

        function createTileWMSBaseMapLayer(lyrObj, lyrUrl) {
            return new ol.layer.Tile({
                id: lyrObj.id,
                title: lyrObj.label,
                source: new ol.source.XYZ({
                    url: lyrUrl
                }),
                zIndex: -1
            })
        }

        function CreateAMSLayer(lyrObj, lyrUrl) {
            return new ol.layer.Tile({
                id: lyrObj.id,
                source: new ol.source.TileArcGISRest({
                    // url: 'https://deventerprisegisarcgis.nexteraenergy.com/server/rest/services/FPL/AMS_Gulf_Electric_Distribution/MapServer'
                    // url: 'https://deventerprisegisarcgis.nexteraenergy.com/server/rest/services/FPL/AMS_Gulf_Electric_Distribution/MapServer/',
                    url: lyrUrl,
                    params: { layers: 'show:' + lyrObj.layerorder }
                }),
                visible: lyrObj.isvisible
            });


        }

        function careateOSMLayer(lyrObj, lyrUrl) {

            return new ol.layer.Tile({
                id: lyrObj.id,
                source: new ol.source.OSM(),
                zIndex: -1
            });
        }

        function createWeatherLayer(lyrObj, lyrUrl) {

            return new ol.layer.Image({
                id: lyrObj.id,
                title: lyrObj.label,
                source: new ol.source.ImageArcGISRest({
                    ratio: 2,
                    params: {},
                    url: lyrUrl
                }),

                visible: lyrObj.isvisible
            });

            // return new ol.layer.Tile({
            //     id: lyrObj.id,
            //     source: new ol.source.TileArcGISRest({
            //         // url: 'https://deventerprisegisarcgis.nexteraenergy.com/server/rest/services/FPL/AMS_Gulf_Electric_Distribution/MapServer'
            //         // url: 'https://deventerprisegisarcgis.nexteraenergy.com/server/rest/services/FPL/AMS_Gulf_Electric_Distribution/MapServer/',
            //         url: lyrUrl,
            //         params: {FORMAT:'PNG'},
                    
            //     }),
            //     visible: lyrObj.isvisible
            // });

        }


        return {
            getLayerMetadata: getLayerMetadata,
            createTileWMSLayer: createTileWMSLayer,
            createWeatherLayer: createWeatherLayer,
            createTileWMSBaseMapLayer: createTileWMSBaseMapLayer,
            careateOSMLayer: careateOSMLayer,
            CreateAMSLayer: CreateAMSLayer,
            createTileWMTSLayer: createTileWMTSLayer

        };
    } catch (e) {
        console.log(e);
    }
}());