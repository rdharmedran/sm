	var layerlist=[];

var layermanager =(function(){
    'use strict';
    try {

       
        function AddlayersOnMap()
        {
		console.log(LAYER_METADATA);
	
        $.each(LAYER_METADATA, function(i, ctgy) {
        
            $.each(ctgy.mapped_layers, function(j, mappedlayer){
                var lyr = {};
                lyr['id'] = mappedlayer.layer_id;
                lyr['name'] = mappedlayer.layer_name;
                lyr['ctgyid'] = ctgy.ctgy_id;
                lyr['ctgyname'] = ctgy.ctgy_name;
                lyr['label'] = mappedlayer.layer_id;
                lyr['layertype'] = mappedlayer.layer_type;
                lyr['url'] = mappedlayer.layer_url;
                lyr['isvisible'] = mappedlayer.layer_on_load === 'Y' ? true : false;
                 lyr['ctgylorder'] = ctgy.layer_ctgy_order;
                lyr['maporder'] = mappedlayer.provider;
                lyr['geometrycolumn'] = mappedlayer.geometry_column;
                 lyr['geometrytype'] = mappedlayer.geometry_type;
                lyr['layer'] = null;
        
                if (lyr['layertype'] == "WMS") {
           
                    lyr.layer = layerDataManager.createTileWMSLayer(lyr, lyr['url'] );
                
                }
        
                else if (lyr['layertype'] == "WMTS") {
           
                    lyr.layer = layerDataManager.createTileWMTSLayer(lyr, lyr['url'] );
                
                }
				map.addLayer(lyr.layer);
                layerlist.push(lyr);
				console.log(layerlist);
               
        
               
        });
        });

        
        }


        function layerOnOff(){
            $('#region').change(function() {
                if(this.checked) {
                   layerlist[0].layer.setVisible(true);
                }
				else{
				layerlist[0].layer.setVisible(false);
				}
                  
            });
            $('#district').change(function() {
                if(this.checked) {
                    layerlist[1].layer.setVisible(true);
                }
				else{
               layerlist[1].layer.setVisible(false);
             }				
            });
            $('#regionname').change(function() {
                if(this.checked) {
                  layerlist[2].layer.setVisible(true);
                }
                else{
				layerlist[2].layer.setVisible(false);
                   }				
            });
        }

        
   
          return {
            AddlayersOnMap:AddlayersOnMap,
			layerOnOff:layerOnOff
          };
        

    }
    catch(e) {
        console.log(e);
    }
}());