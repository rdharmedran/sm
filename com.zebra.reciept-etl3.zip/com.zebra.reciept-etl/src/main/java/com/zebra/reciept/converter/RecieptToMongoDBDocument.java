package com.zebra.reciept.converter;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.sdk.transforms.DoFn;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.zebra.reciept.model.v1.RecieptDocument;

public class RecieptToMongoDBDocument extends DoFn<GenericRecord, Document> {

	private static final long serialVersionUID = 1462827258689031685L;
	private static final Logger LOG = LoggerFactory.getLogger(RecieptToMongoDBDocument.class);
	
	@ProcessElement
	public void processElement(ProcessContext c) throws Exception {
		try {
			  c.output(new Document("value", c.element().toString()));
			
		} catch(Exception e)
		{
			//e.printStackTrace();
			LOG.error("Exception in processing packet:"+e.getMessage(), e);
		}
			}
}