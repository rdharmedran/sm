package com.zebra.reciept.config;

import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.Validation;
import org.apache.beam.sdk.options.ValueProvider;

/** Options for the import pipeline. */
public interface ETLOptions extends PipelineOptions {

	@Description("The input file patterm to read from. (e.g. gs://mybucket/somefolder/table1*.parquet)")
	@Default.String("gs://zebra_poc/Zebra/parquet/data_3.parquet/*")
	ValueProvider<String> getInputFilePattern();

	@SuppressWarnings("unused")
	void setInputFilePattern(ValueProvider<String> inputFilePattern);

	//@Description("The MongoDB database to push the Documents to.")
	@Validation.Required
	@Default.String("retail")
	String getDatabase();

	void setDatabase(String database);

	@Description("The host addresses of the MongoDB"
			+ "Multiple addresses to be specified with a comma separated value e.g."
			+ "host1:port,host2:port,host3:port")
	//@Validation.Required
	@Default.String("mongodb+srv://user1:user123@cluster0.4x2hx.mongodb.net/retail")
	String getMongoDBUri();

	void setMongoDBUri(String mongoDBUri);

	@Description("The Collection in mongoDB to put documents to.")
	//@Validation.Required
	@Default.String("retail")
	String getCollection();

	void setCollection(String collection);

	@Description("Batch size in number of documents. Default: 1000")
	@Default.Long(1024)
	Long getBatchSize();

	void setBatchSize(Long batchSize);

	@Description("Batch size in number of bytes. Default: 5242880 (5mb)")
	@Default.Long(5242880)
	Long getBatchSizeBytes();

	void setBatchSizeBytes(Long batchSizeBytes);

	@Description("Maximum Connection idle time in ms. Default: 60000")
	@Default.Integer(60000)
	int getMaxConnectionIdleTime();

	void setMaxConnectionIdleTime(int maxConnectionIdleTime);

	@Description("Specify if SSL is enabled. Default: true")
	@Default.Boolean(true)
	Boolean getSslEnabled();

	void setSslEnabled(Boolean sslEnabled);

	@Description("Specify whether to ignore SSL certificate. Default: true")
	@Default.Boolean(true)
	Boolean getIgnoreSSLCertificate();

	void setIgnoreSSLCertificate(Boolean ignoreSSLCertificate);

	@Description("Enable ordered bulk insertions. Default: true")
	@Default.Boolean(true)
	Boolean getWithOrdered();

	void setWithOrdered(Boolean withOrdered);

	@Description("Enable invalidHostNameAllowed for ssl connection. Default: true")
	@Default.Boolean(true)
	Boolean getWithSSLInvalidHostNameAllowed();

	void setWithSSLInvalidHostNameAllowed(Boolean withSSLInvalidHostNameAllowed);
}
