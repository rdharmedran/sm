package com.zebra.reciept.converter;
import org.apache.avro.generic.GenericRecord;
import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.zebra.reciept.model.v1.RecieptDocument;

public class GenericRecordToReciptProcess extends DoFn<GenericRecord, RecieptDocument> {

	private static final long serialVersionUID = 1462827258689031685L;
	private static final Logger LOG = LoggerFactory.getLogger(GenericRecordToReciptProcess.class);
	private ObjectMapper objectMapper;
	
	@Setup
    public void initOpenCsv() {
		objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.setDefaultPropertyInclusion(JsonInclude.Include.NON_NULL).setSerializationInclusion(Include.NON_NULL);
    }
	
	@ProcessElement
	public void processElement(ProcessContext c) throws Exception {
		System.out.println(">>>>>>>>>>>ddddddddddddddddddd>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+c.element());
		try {
			RecieptDocument reciept = objectMapper.readValue(c.element().toString(), RecieptDocument.class);		
			System.out.println("JsonStringToReciptProcess>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+reciept.toString());
			//reciept.
			c.output(reciept);
			
		} catch(Exception e)
		{
			//e.printStackTrace();
			LOG.error("Exception in processing packet:"+e.getMessage(), e);
		}
			}
}