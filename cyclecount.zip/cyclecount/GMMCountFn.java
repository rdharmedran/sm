package com.macys.cyclecount;

import java.util.stream.StreamSupport;

import org.apache.beam.sdk.io.redis.RedisConnectionConfiguration;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.state.ValueState;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Jedis;

public class GMMCountFn extends DoFn<KV<Row, Iterable<Row>>, Row> {

	private static final Logger LOG = LoggerFactory.getLogger(GMMCountFn.class);
	final Schema gmmRowSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID").addStringField("COUNT").build();

	@StateId("Value")
	private final StateSpec<ValueState<Long>> keyState = StateSpecs.value();
	Jedis client;

	@StartBundle
	public void startBundle(StartBundleContext c) {
		LOG.info("\n GMMCountFn>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started");
		client = RedisConnectionConfiguration.create("127.0.0.1", 6379).connect();
	}

	@FinishBundle
	public void finishBundle(FinishBundleContext c) {
		LOG.info("\n GMMCountFn>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: finished");
		client.close();
	}

	@ProcessElement
	public void processElement(ProcessContext context, @StateId("Value") ValueState<Long> valueState) {
		try {
			LOG.info(context.element().getKey()+"\n GMMCountFn>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started"+context.element().getValue());

			final Row key = context.element().getKey();
			Long remainingCount = valueState.read();
			final String keyString = new StringBuffer().append(key.getString("INV_SCAN_GRP_ID")).append("_")
					.append(key.getString("INV_SCAN_HDR_ID")).append("_").append(key.getString("GMM_ID")).toString();
			if (remainingCount == null) {
				LOG.info(context.element().getKey()+"\n remainingCount>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started"+remainingCount);

				final String valueFromRedis = client.get(keyString);
				if (null != valueFromRedis) {
					final String[] valueArray = valueFromRedis.split("_");
					final long targetCount = Long.parseLong(valueArray[3]);
					remainingCount = targetCount;
				} else {
					// @todo get it from spanner
					remainingCount = 0l;
				}
			}
			final Iterable<Row> inputRow = context.element().getValue();
			final long count = StreamSupport.stream(inputRow.spliterator(), false).count();
			final Long currentRemainingCount = remainingCount - count;
			LOG.info(context.element().getKey()+"\n currentRemainingCount>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started"+currentRemainingCount);

			valueState.write(currentRemainingCount);

			context.output(Row.withSchema(gmmRowSchema).addValues(context.element().getKey().getString("INV_SCAN_GRP_ID")
					, context.element().getKey().getString("INV_SCAN_HDR_ID")
					,context.element().getKey().getString("GMM_ID")
					, String.valueOf(currentRemainingCount)).build());
			LOG.info(context.element().getKey()+"\n gmm end>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started"+Row.withSchema(gmmRowSchema).addValues(context.element().getKey().getString("INV_SCAN_GRP_ID")
					, context.element().getKey().getString("INV_SCAN_HDR_ID")
					,context.element().getKey().getString("GMM_ID")
					, String.valueOf(currentRemainingCount)).build());


		} catch (final Exception e) {
			LOG.error("GMMCountFn error occurred", e);
		}

	}

}
