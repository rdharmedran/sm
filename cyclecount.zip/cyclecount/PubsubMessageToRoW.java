package com.macys.cyclecount;

import static java.util.stream.Collectors.toList;
import static org.apache.beam.sdk.util.RowJsonUtils.newObjectMapperWith;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Nullable;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.redis.RedisConnectionConfiguration;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.util.RowJson.RowJsonDeserializer;
import org.apache.beam.sdk.util.RowJson.UnsupportedRowJsonException;
import org.apache.beam.sdk.util.RowJsonUtils;
import org.apache.beam.sdk.values.Row;
import org.joda.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

public class PubsubMessageToRoW extends DoFn<PubsubMessage, Row> {
	private static final Logger LOG = LoggerFactory.getLogger(PubsubMessageToRoW.class);

	private static final long serialVersionUID = 1L;
	static final String TIMESTAMP_FIELD = "event_timestamp";
	static final String ATTRIBUTES_FIELD = "attributes";
	static final String PAYLOAD_FIELD = "payload";

	private final Schema messageSchema;

	private final Schema payloadSchema;

	private final boolean useDlq;

	private transient volatile @Nullable ObjectMapper objectMapper;

	protected PubsubMessageToRoW(Schema messageSchema, boolean useDlq) {
		this.messageSchema = messageSchema;
		// Construct flat payload schema.
		this.payloadSchema = new Schema(messageSchema.getFields().stream()
				.filter(f -> !f.getName().equals(TIMESTAMP_FIELD)).collect(Collectors.toList()));
		this.useDlq = useDlq;
	}


	@StartBundle
	public void startBundle(StartBundleContext c) {
		LOG.info("\n PubsubMessageToRoW>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started");
	}

	@FinishBundle
	public void finishBundle(FinishBundleContext c) {
		LOG.info("\n PubsubMessageToRoW>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: finished");
	}
	
	/**
	 * Get the value for a field from a given payload in the order they're specified
	 * in the flat schema.
	 */
	private Object getValueForFieldFlatSchema(Schema.Field field, Instant timestamp, Row payload) {
		final String fieldName = field.getName();
		if (TIMESTAMP_FIELD.equals(fieldName)) {
			return timestamp;
		} else {
			return payload.getValue(fieldName);
		}
	}

	private Row parsePayload(PubsubMessage pubsubMessage) {
		final String payloadJson = new String(pubsubMessage.getPayload(), StandardCharsets.UTF_8);
		if (objectMapper == null) {
			objectMapper = newObjectMapperWith(RowJsonDeserializer.forSchema(payloadSchema));
		}

		return RowJsonUtils.jsonToRow(objectMapper, payloadJson);
	}

	@ProcessElement
	public void processElement(@Element PubsubMessage element, @Timestamp Instant timestamp, ProcessContext c) {
		try {
			final Row payload = parsePayload(element);
			final List<Object> values = messageSchema.getFields().stream()
					.map(field -> getValueForFieldFlatSchema(field, timestamp, payload)).collect(toList());
			c.output(Row.withSchema(messageSchema).addValues(values).build());
		} catch (final UnsupportedRowJsonException jsonException) {

		}
	}
}
