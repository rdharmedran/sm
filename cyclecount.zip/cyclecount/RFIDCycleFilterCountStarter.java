package com.macys.cyclecount;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * RFID Scanning Dataflow to read data from pubsub and write data
 *
 *
 *
 *
 *
 */
public class RFIDCycleFilterCountStarter {

	private static final String DEVICE_SCAN_DATA_SUBSCRIPTION = "device.scan.data.filtercount.subscription.name";

	private static final String ACTION_REQUEST = "actionRequest";

	private static final String SCAN_SESSION_ID = "scanSessionId";

	private static final String TOTAL_COUNT_QUERY = "select InvScanHdrID,count(*) as totalCount from InvScanEpc where InvScanHdrID = @inscanHeaderId group by InvScanHdrID";

	private static final String GROUP_COUNT_QUERY = "select InvScanHdrID,count(*) as actualCount from InvScanEpc where InvScanHdrID = @inscanHeaderId and DeptNbr!=0 and VndNbr!=0  group by InvScanHdrID";

	private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleFilterCountStarter.class);

	public static void main(String[] args) throws Exception {

		/* .................Loading configuration starts ................ */
		Properties configProperties = null;
		try {
			configProperties = RFIDCycleCountUtil.readPropertiesFile();
		} catch (final IOException e) {
			LOG.error("Error reading configuration file::" + e);
		}
		final PipelineOptions options = PipelineOptionsFactory.create();

		/* .................Loading configuration ends ................ */

		configProperties.getProperty("gcp.project.id");
		configProperties.getProperty("spanner.instance.id");
		configProperties.getProperty("spanner.database.id");
		final Pipeline rfidScanPipeline = Pipeline.create(options);
		LOG.info("Pipeline started");

		/* .................Schema declarations starts ................ */
		final Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
				.addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
				.addStringField("EPC_URN").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();

		Schema.builder().addStringField("INV_SCAN_GRP_ID")
		.addStringField("INV_SCAN_HDR_ID")

		.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN")
		.addStringField("DEPT_NBR")

		.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS")

		.addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("TARGET_COUNT").build();
		Schema.builder().addStringField("INV_SCAN_GRP_ID")
		.addStringField("INV_SCAN_HDR_ID").build();
		Schema.builder().addStringField("GMM_ID").addStringField("COUNT").build();

		Schema.builder().addInt64Field(SCAN_SESSION_ID).addStringField(ACTION_REQUEST)
		.addStringField("userId").build();

		Schema.builder().addStringField("INV_SCAN_GRP_ID")
		.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID")

		.build();

		/* ................. load lookup tables starts ................ */
		@SuppressWarnings("serial")
		final PCollectionView<Map<String, String>> displayEpcMap = rfidScanPipeline
		.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
		.apply(Window.<Long>into(new GlobalWindows())
				.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
				.discardingFiredPanes())
		.apply(ParDo.of(new DisplayTagLoader())).apply(View.<String, String>asMap());

		/* ................. load lookup tables ends ................ */
		;
		final PCollection<PubsubMessage> scanMessage = rfidScanPipeline.apply("ReadPubsub",
				PubsubIO.readMessagesWithAttributes().withIdAttribute("UNIQUE_ID")
				.fromSubscription(configProperties.getProperty(DEVICE_SCAN_DATA_SUBSCRIPTION)));

		/*
		 * ---------------------------------- convert pubsub message to row object
		 * -------------------
		 */

		final PCollection<Row> scanDataRow = scanMessage
				.apply(ParDo.of(new PubsubMessageToRoW(rfidScanDataSchema, false)));

		/*
		 * --------------- create micro batches for message with 30 seconds
		 * window---------------
		 */

		final PCollection<Row> windowedData = scanDataRow.setCoder(RowCoder.of(rfidScanDataSchema))
				.apply(Window.<Row>into(FixedWindows.of(Duration.standardSeconds(60)))
						.withAllowedLateness(Duration.standardSeconds(5), Window.ClosingBehavior.FIRE_ALWAYS)
						.discardingFiredPanes());

		final PCollection<Row> windowedscanData = windowedData.apply(ParDo.of(new DoFn<Row, Row>() {
			@ProcessElement
			public void processElement(ProcessContext c) {
				c.element().getString("EPC_HEX");
				c.pane().getIndex();
				// LOG.info(timing+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>. Attribute:: " + epcHex);
				c.output(c.element());
			}
		}));

		/*
		 * ----------------------------group the message with group
		 * id---------------------
		 */
		final PCollection<KV<String, Row>> windowedStreamData = windowedscanData
				.setCoder(RowCoder.of(rfidScanDataSchema))
				.apply("Set EPC Header Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
						.via(row1 -> KV.of(row1.getString("INV_SCAN_HDR_ID"), row1)))
				.setRowSchema(rfidScanDataSchema);

		final PCollection<KV<String, Iterable<Row>>> groupIdKV = windowedStreamData
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());

		/*------- remove display tag from stream using filter ----------------   */

		final PCollection<KV<String, Row>> displayremovedKV = groupIdKV.apply("FilterDisplay Tags",
				ParDo.of(new DisplayTagRemoverFn(displayEpcMap)).withSideInputs(displayEpcMap));

		final PCollection<KV<String, Iterable<Row>>> displayremovedByGroupId = displayremovedKV
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());
		final PCollection<KV<String, Long>> kvs = displayremovedKV.apply("Count occurrences per key", Count.perKey());

		kvs.apply(Combine.<String, Long, Long>perKey(Sum.ofLongs()));

		/*
		 * ------------------------ populate vendor number and department number by
		 * ---------
		 */

		displayremovedByGroupId
		.apply(ParDo.of(new DVNFilterEnrichentFn(configProperties)));

		rfidScanPipeline.run().waitUntilFinish();
	}
}
