package com.macys.cyclecount;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class InvScanEpcToMutationFn extends DoFn<KV<String, Row>, Mutation> {
	private static final Logger LOG = LoggerFactory.getLogger(InvScanEpcToMutationFn.class);
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	@ProcessElement
	public void processElement(ProcessContext c) {
		Row inputRow = c.element().getValue();
		long scnGrpId = Long.parseLong(inputRow.getString("INV_SCAN_GRP_ID"));
		long hdrId = Long.parseLong(inputRow.getString("INV_SCAN_HDR_ID"));
		long skuUpcNmbr = 0;
		try {
			skuUpcNmbr = Long.parseLong(inputRow.getString("SKU_UPC_NBR"));
		} catch (Exception e) {
			LOG.error("SKU UPC Number Invalid");
		}
		com.google.cloud.Timestamp scanTs = com.google.cloud.Timestamp.parseTimestamp(inputRow.getString("SCAN_TS"));
		Mutation scanDataMutation = Mutation.newInsertOrUpdateBuilder("InvScanEpc").set("InvScanGrpID").to(scnGrpId)
				.set("EpcHex").to(inputRow.getString("EPC_HEX")).set("DeptNbr").to(inputRow.getString("DEPT_NBR"))
				.set("EpcUrn").to(inputRow.getString("EPC_URN")).set("InvScanHdrID").to(hdrId).set("RunID").to(0)
				.set("ScanTS").to(scanTs).set("SkuUpcNbr").to(skuUpcNmbr).set("UserID")
				.to(inputRow.getString("USER_ID")).set("VndNbr").to(inputRow.getString("VND_NBR")).build();
		c.output(scanDataMutation);
	}

}
