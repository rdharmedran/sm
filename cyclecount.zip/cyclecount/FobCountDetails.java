package com.macys.cyclecount;



import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "groupId",
    "sessionId",
    "gmmId",
    "zoneName",
    "totalCount",
    "gmmCounts"
})
public class FobCountDetails {

    @JsonProperty("groupId")
    private Long groupId;
    @JsonProperty("sessionId")
    private Long sessionId;
    @JsonProperty("gmmId")
    private Long gmmId;
    @JsonProperty("gmmId")
    public Long getGmmId() {
		return gmmId;
	}
    @JsonProperty("gmmId")
	public void setGmmId(Long gmmId) {
		this.gmmId = gmmId;
	}

	@JsonProperty("zoneName")
    private String zoneName;
    @JsonProperty("totalCount")
    private Long totalCount;
    @JsonProperty("fobCounts")
    private List<FobCount> fobCounts = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("groupId")
    public Long getGroupId() {
        return groupId;
    }

    @JsonProperty("groupId")
    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }

    @JsonProperty("sessionId")
    public Long getSessionId() {
        return sessionId;
    }

    @JsonProperty("sessionId")
    public void setSessionId(Long sessionId) {
        this.sessionId = sessionId;
    }

    @JsonProperty("zoneName")
    public String getZoneName() {
        return zoneName;
    }

    @JsonProperty("zoneName")
    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    @JsonProperty("totalCount")
    public Long getTotalCount() {
        return totalCount;
    }

    @JsonProperty("totalCount")
    public void setTotalCount(Long totalCount) {
        this.totalCount = totalCount;
    }

    @JsonProperty("fobCounts")
    public List<FobCount> getFobCounts() {
        return fobCounts;
    }

    @JsonProperty("fobCounts")
    public void setFobCounts(List<FobCount> fobCounts) {
        this.fobCounts = fobCounts;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

   

}
