package com.macys.cyclecount;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PrintFn extends DoFn<Row, Row> {
	private static final Logger LOG = LoggerFactory.getLogger(PrintFn.class);

	// @StateId("Value")
	// private final StateSpec<MapState<String, Long>> mapState = StateSpecs.map();

	@ProcessElement
	public void processElement(ProcessContext c) {
		c.element().getString("EPC_HEX");
		c.pane().getIndex();
		// client.set(epcHex, epcHex);
		// LOG.info(client.get(epcHex)+">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>. Attribute:: "
		// + epcHex);
		c.output(c.element());
	}

}
