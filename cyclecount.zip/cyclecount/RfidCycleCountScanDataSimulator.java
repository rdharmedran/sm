package com.macys.cyclecount;

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.extensions.sql.SqlTransform;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.collect.ImmutableBiMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.Struct;



/**
* RFID Scanning Dataflow to read data from pubsub and write data 
 *
*
*/
public class RfidCycleCountScanDataSimulator
{
  private static final Logger LOG = LoggerFactory.getLogger(RfidCycleCountScanDataSimulator.class);

  public static void main(String[] args) {
                  PipelineOptions options = PipelineOptionsFactory.create();
                  Pipeline rfidScanPipeline = Pipeline.create(options);
                  LOG.info("Simulator started");
                  
                  /*Begin of Load Test data For Dev */
                PCollection<Struct> testData = rfidScanPipeline.apply(SpannerIO.read().withInstanceId("cspanner-storesys-np")
              .withDatabaseId("rfid-db-dev").withProjectId("mtech-storesys-np").withBatching(false)
              .withQuery("SELECT EpcHex,EpcUrn,ScanTS,SkuUpcNbr FROM EpcTestData where ZlDivnNbr=71 and  ZlStoreNbr=733 limit 1"));
                testData.apply(ParDo.of(new DoFn<Struct, PubsubMessage>(){
                                  @ProcessElement
                                  public void processElement(ProcessContext context){
                                	   LOG.info("Simulator started");
                                    Struct testData =context.element();
                                    LOG.info("Simulator started"+testData);
                                    String invScanGrpId = "1092";
                                    String EPC_HEX = testData.getString("EpcHex");
                                    String invScanHdrId = "101501";
                                    String scanTS = testData.getTimestamp("ScanTS").toString();
                                    String EPC_URN = testData.getString("EpcUrn");
                                    String userId = "X000628";
                                    String skuUpc =  new Long(testData.getLong("SkuUpcNbr")).toString();
                                    String jsonString = "{\"INV_SCAN_GRP_ID\":\""+invScanGrpId+"\",\"INV_SCAN_HDR_ID\":\""+invScanHdrId+"\",\"USER_ID\":\""+userId+"\",\"EPC_HEX\":\""+EPC_HEX+"\",\"EPC_URN\":\""+EPC_URN+"\",\"SKU_UPC_NBR\":\""+skuUpc+"\",\"SCAN_TS\":\""+scanTS+"\"}";
                                    LOG.info(jsonString);
                                    PubsubMessage mesg = new PubsubMessage(jsonString.getBytes(),ImmutableBiMap.of("UNIQUE_ID", invScanGrpId+EPC_HEX));
                                    context.output(mesg);
                                  }
                  }))
                  //.         apply(PubsubIO.writeMessages().to("projects/mtech-storesys-np/topics/test-rfid"));
                  .apply(PubsubIO.writeMessages().to("projects/mtech-storesys-np/topics/cycle-count-device-scan-data-rfid-np-dev"));

                PCollection<Struct> testData7 = rfidScanPipeline.apply(SpannerIO.read().withInstanceId("cspanner-storesys-np")
                        .withDatabaseId("rfid-db-dev").withProjectId("mtech-storesys-np").withBatching(false)
                        .withQuery( "Select tw.EpcHex " + 
                                "from TagsWritten tw " + 
                                "Where TW.ActiveFlag = 'A' " +
                                                  " AND TW.zldivnnbr = 71 and TW.zlstorenbr = 3 and zonename = 'Display Mens Shoes' limit 15"
                    ));
                testData7.apply(ParDo.of(new DoFn<Struct, PubsubMessage>(){
                                            @ProcessElement
                                            public void processElement(ProcessContext context){
                                          	   LOG.info("Simulator started7");
                                              Struct testData =context.element();
                                              LOG.info("Simulator started7"+testData);
                                              String invScanGrpId = "1092";
                                              String EPC_HEX = testData.getString("EpcHex");
                                              String invScanHdrId = "101501";
                                              String scanTS = "2020-02-24T07:55:03Z";
                                              String EPC_URN = "urn:epc:tag:sgtin-96:0.000000000000.0.5654090011";
                                              String userId = "X000628";
                                              String skuUpc =  new Long("749709900746").toString();
                                              String jsonString = "{\"INV_SCAN_GRP_ID\":\""+invScanGrpId+"\",\"INV_SCAN_HDR_ID\":\""+invScanHdrId+"\",\"USER_ID\":\""+userId+"\",\"EPC_HEX\":\""+EPC_HEX+"\",\"EPC_URN\":\""+EPC_URN+"\",\"SKU_UPC_NBR\":\""+skuUpc+"\",\"SCAN_TS\":\""+scanTS+"\"}";
                                              LOG.info(jsonString);
                                              PubsubMessage mesg = new PubsubMessage(jsonString.getBytes(),ImmutableBiMap.of("UNIQUE_ID", invScanGrpId+EPC_HEX));
                                              context.output(mesg);
                                            }
                            }))
                            //.         apply(PubsubIO.writeMessages().to("projects/mtech-storesys-np/topics/test-rfid"));
                            .apply(PubsubIO.writeMessages().to("projects/mtech-storesys-np/topics/cycle-count-device-scan-data-rfid-np-dev"));
                 
     rfidScanPipeline.run().waitUntilFinish();
  }
}
