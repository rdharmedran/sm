package com.macys.cyclecount;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.Row;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.redis.RedisConnectionConfiguration;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.PDone;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.macys.cyclecount.async.SpannerWriteDoFn;

import redis.clients.jedis.Jedis;

public class CalculateFOBCount extends PTransform<PCollection<KV<String, Row>>, PDone> {
	private final Duration allowedLateness;
	private Properties configProperties;
	static final Duration TWO_MINUTES = Duration.standardMinutes(3);

	CalculateFOBCount(Duration allowedLateness,Properties configProperties) {
		this.allowedLateness = allowedLateness;
		this.configProperties=configProperties;
	}

	public static final Schema fobRowSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID") .addStringField("FOB_ID").addStringField("COUNT").build();
	
	
    Schema fobDataLoadSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")

            .addStringField("GMM_ID") .addStringField("FOB_ID").addStringField("FOB_NAME").addStringField("COUNT").build();
    
    
	final Schema rfidScanGMMKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID").build();
	final Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
			.addStringField("EPC_URN").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();

	Schema fobValueSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")

			.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN").addStringField("DEPT_NBR")

			.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS")
			
			

			.addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("FOB_ID").addStringField("FOB_NAME").addStringField("TARGET_COUNT").build();
	Schema enrichedMessageSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")

			.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN").addStringField("DEPT_NBR")

			.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS")

			.addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("FOB_ID").addStringField("FOB_NAME")

			.build();
	
	final Schema fobKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID").build();
	final Schema fobCountSchema = Schema.builder().addStringField("FOB_ID").addStringField("COUNT").build();

	final Schema fopKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID").addStringField("FOB_ID")

			.build();
	/* .................... Schema declarations ends ................ */

	@Override
	public PDone expand(PCollection<KV<String, Row>> input) {
		return input.apply("Fob Count publisher", Window.<KV<String, Row>>into(FixedWindows.of(Duration.standardSeconds(30)))
				// Get periodic results every ten minutes.
				.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane().plusDelayOf(TWO_MINUTES)))
				.discardingFiredPanes().withAllowedLateness(allowedLateness)).apply(Values.<Row>create())
				.apply("Group Fob Rows",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
								.via(row1 -> KV.of(Row.withSchema(fopKeySchema)
										.addValues(row1.getString("INV_SCAN_GRP_ID"), row1.getString("INV_SCAN_HDR_ID"),
												row1.getString("GMM_ID"),row1.getString("FOB_ID"))
										.build(), row1)))
				.setCoder(KvCoder.of(RowCoder.of(fopKeySchema), RowCoder.of(enrichedMessageSchema)))
				.apply(GroupByKey.<Row, Row>create()).apply("Fob Count", ParDo.of(new FobCountFn()))
				.setCoder(RowCoder.of(fobRowSchema))
				.apply("Group  Fob Count",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
								.via(row1 -> KV.of(
										Row.withSchema(fobKeySchema)
												.addValues(row1.getString("INV_SCAN_GRP_ID"),
														row1.getString("INV_SCAN_HDR_ID"),row1.getString("GMM_ID"))
												.build(),
										Row.withSchema(fobCountSchema)
												.addValues(row1.getString("FOB_ID"), row1.getString("COUNT")).build())))
				.setCoder(KvCoder.of(RowCoder.of(fobKeySchema), RowCoder.of(fobCountSchema)))
				.apply(GroupByKey.<Row, Row>create()).apply("Convert to JSON", ParDo.of(new FobCountToJsonFn()))
				.apply("Write Fob Count To Pubsub",
						PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));

		// Extract and sum username/score pairs from the event data.

	}
}
// [END DocInclude_ProcTimeTrigger]
