package com.macys.cyclecount;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.Row;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.redis.RedisConnectionConfiguration;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.PDone;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.macys.cyclecount.async.SpannerWriteDoFn;

import redis.clients.jedis.Jedis;

public class CalculateGroupCount extends PTransform<PCollection<KV<String, Row>>, PDone> {
	private static final Logger LOG = LoggerFactory.getLogger(CalculateGroupCount.class);
	private final Duration allowedLateness;
	private Properties configProperties;
	static final Duration ONE_MINUTES = Duration.standardMinutes(1);

	CalculateGroupCount(Duration allowedLateness,Properties configProperties) {
		this.allowedLateness = allowedLateness;
		this.configProperties=configProperties;
		this.SPANNER_PROJECT_ID = configProperties.getProperty("gcp.project.id");
		this.SPANNER_INSTANCE_ID = configProperties.getProperty("spanner.instance.id");
		this.SPANNER_DATABASE_ID = configProperties.getProperty("spanner.database.id");
	}
	 String SPANNER_PROJECT_ID ;
	 String SPANNER_INSTANCE_ID;
	String SPANNER_DATABASE_ID;
	
			
	/* .................... Schema declarations ends ................ */

	@Override
	public PDone expand(PCollection<KV<String, Row>> input) {
		final PCollection<String> groupCountJson =  input.apply("LeaderboardUserGlobalWindow", Window.<KV<String, Row>>into(FixedWindows.of(Duration.standardSeconds(30)))
				// Get periodic results every ten minutes.
				.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane().plusDelayOf(ONE_MINUTES)))
				.discardingFiredPanes().withAllowedLateness(allowedLateness))
				.apply(GroupByKey.<String, Row>create())
				.apply(ParDo.of(new GroupCountFn()))
				.apply("Take Group Count", ParDo.of(new GroupCountToJsonFn()));
//		try {
//		groupCountJson.apply("Write Count To Database", ParDo.of(new GroupCountToMutationFn2())).apply(
//						"WriteGroupCountToHeader",
//						SpannerIO.write().withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID));
//		}catch(Exception e) {
//			LOG.error("Error occurred while inserting Group Count to Table",e);
//		}
		return groupCountJson.apply("Write Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
				

		// Extract and sum username/score pairs from the event data.

	}
}
// [END DocInclude_ProcTimeTrigger]
