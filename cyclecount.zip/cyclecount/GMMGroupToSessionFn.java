package com.macys.cyclecount;

import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.state.TimeDomain;
import org.apache.beam.sdk.state.TimerSpec;
import org.apache.beam.sdk.state.TimerSpecs;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.OnTimer;
import org.apache.beam.sdk.transforms.DoFn.OnTimerContext;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.transforms.DoFn.TimerId;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GMMGroupToSessionFn extends DoFn<KV<Row, Long>,KV<String, Row>> {
	private static final Logger LOG = LoggerFactory.getLogger(GMMGroupToSessionFn.class);
	   final Schema rfidScanGrpKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
   			.build();
	   final Schema rfidScanGrpValueSchema = Schema.builder().addStringField("GMM_ID").addStringField("COUNT")
	   			.build();


	@ProcessElement
	public void processElement(ProcessContext c) {
		try {
		LOG.info(c.element().getKey()+"<><><><><>>>NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>."+c.element().getValue());
			
					 // .collect(Collectors.summingLong(Long::longValue));
			
			
			
			final Row keyRow = Row.withSchema(rfidScanGrpKeySchema)
					 .withFieldValue("INV_SCAN_GRP_ID", c.element().getKey().getString("INV_SCAN_GRP_ID"))
					.withFieldValue("INV_SCAN_HDR_ID", c.element().getKey().getString("INV_SCAN_HDR_ID")).build();
			
			
			final Row valueRow = Row.withSchema(rfidScanGrpValueSchema)
					 .withFieldValue("GMM_ID", c.element().getKey().getString("GMM_ID"))
					.withFieldValue("COUNT", String.valueOf(c.element().getValue())).build();
		LOG.info(keyRow+"GMMGroupToSessionFnGMMGroupToSessionFnGMMGroupToSessionFnGMMGroupToSessionFnGMMGroupToSessionFn."+valueRow);
			c.output(KV.of( (c.element().getKey().getString("INV_SCAN_GRP_ID")+"_"+c.element().getKey().getString("INV_SCAN_HDR_ID")), valueRow));
			
		} catch (final Exception e) {
			LOG.error("Exception occurred",e);
		}

	}
	
	 
}


