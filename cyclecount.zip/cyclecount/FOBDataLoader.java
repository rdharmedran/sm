package com.macys.cyclecount;

 

import java.io.IOException;

import java.util.Properties;

 

import org.apache.beam.sdk.transforms.PTransform;

import org.apache.beam.sdk.transforms.View;

import org.apache.beam.sdk.io.redis.RedisConnectionConfiguration;

import org.apache.beam.sdk.schemas.Schema;

import org.apache.beam.sdk.transforms.DoFn;

import org.apache.beam.sdk.transforms.DoFn.FinishBundle;

import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;

import org.apache.beam.sdk.transforms.DoFn.ProcessContext;

import org.apache.beam.sdk.transforms.DoFn.ProcessElement;

import org.apache.beam.sdk.transforms.DoFn.StartBundle;

import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;

import org.apache.beam.sdk.values.KV;

import org.apache.beam.sdk.values.PCollection;

import org.apache.beam.sdk.values.Row;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

 

import com.google.cloud.spanner.DatabaseClient;

import com.google.cloud.spanner.DatabaseId;

import com.google.cloud.spanner.ResultSet;

import com.google.cloud.spanner.Spanner;

import com.google.cloud.spanner.Statement;

import com.google.cloud.spanner.Struct;

import com.google.gson.Gson;



 

import redis.clients.jedis.Jedis;

 

public class FOBDataLoader extends DoFn<Row, KV<String, String>> {

                private static final String INV_SCAN_GRP_ID = "invScanGrpId";

                private static final String TARGET_COUNT = "targetCount";

                private static final String FOB_NAME = "fobname";

                private static final String FOB_ID = "fobId";

                private static final String GROUP_ID = "groupId";

                private static final Logger LOG = LoggerFactory.getLogger(FOBDataLoader.class);

                private static final String START_SCAN = "start-scan";

                private static final String SCAN_SESSION_ID = "scanSessionId";

                private static final String ACTION_REQUEST = "actionRequest";

               

                private static final String FOB_DATA_QUERY = "select groupId,gmmid, fobId, fobname, sum(targetCount) as targetCount from "

+ "(SELECT mh.gmmid as gmmid,mh.divmanid as fobid, mh.divmandesc as fobname, isg.InvScanGrpID as groupid,Trgt.TargetCount as targetCount,  trgt.deptnbr, trgt.vndnbr "

+ "FROM InvScanGrp isg Join TargetCntByDVN Trgt on "

+ "(trgt.zldivnnbr = isg.zldivnnbr and trgt.invnbr = isg.invnbr and trgt.countdate = isg.countdate and trgt.zlstorenbr = isg.zlstorenbr and "

+ "trgt.invfiltersw = 1) join mchhier mh on (mh.zldivnnbr = isg.zldivnnbr and mh.deptnbr = trgt.deptnbr and mh.activeind = 1)  "

+ " where isg.InvScanGrpID=@invScanGrpId "

+ ")group by groupid,gmmid,fobid,fobname";

               

                Schema fobDataLoadSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")

             .addStringField("GMM_ID") .addStringField("FOB_ID").addStringField("FOB_NAME").addStringField("TARGET_COUNT").build();

               

               

 

                private Spanner spanner = null;

                private DatabaseClient dbClient = null;

                Properties configProperties = null;

                Jedis client;

               

                public FOBDataLoader() {

                                try {

                                                configProperties = RFIDCycleCountUtil.readPropertiesFile();

                                } catch (IOException e) {

                                                LOG.error("Error reading configuration file::" + e);

                                }

                }

                @StartBundle

                public void startBundle(StartBundleContext c) {

                                com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions

                                                                .newBuilder().build();

                                spanner = spannerOptions.getService();

                               

                                String spannerProjectID = configProperties.getProperty("gcp.project.id");

                                String spannerInstanceID = configProperties.getProperty("spanner.instance.id");

                                String spannerDatabaseID = configProperties.getProperty("spanner.database.id");

                                DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);

                                dbClient = spanner.getDatabaseClient(db);

                                String REDIS_HOST = configProperties.getProperty("redis.host");

                                int REDIS_PORT = Integer.parseInt(configProperties.getProperty("redis.port"));

                                client = RedisConnectionConfiguration.create(REDIS_HOST, REDIS_PORT).connect();

                }

 

                @FinishBundle

                public void finishBundle(FinishBundleContext c) {

                                try {

                                                dbClient = null;

                                                spanner.close();

                                } catch (Exception e) {

                                                LOG.error("error while loading lookup>>>>>>>>>>>>>>>>>>>>>>>>>", e);

                                }

                }

 

                @ProcessElement

                public void processElement(ProcessContext c) {

                                Row notificationRow = c.element();

                                final String actionRequest = notificationRow.getString(ACTION_REQUEST);

                                final long sessionId = notificationRow.getInt64(SCAN_SESSION_ID);

                                final long groupId = notificationRow.getInt64(GROUP_ID);

                                if (actionRequest.equalsIgnoreCase(START_SCAN)) {

                                                Statement stmtTogetFOBData = Statement.newBuilder(FOB_DATA_QUERY).bind(INV_SCAN_GRP_ID).to(groupId).build();

                                                LOG.info("FOB Data Loading::" + stmtTogetFOBData.toString());

                                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtTogetFOBData);

                                                while (resultSet.next()) {

                                                               

                                                                Struct struct = resultSet.getCurrentRowAsStruct();

                                                                String gmmId = String.valueOf(struct.getLong("gmmid"));

                                                                String groupIdStr =String.valueOf( struct.getLong(GROUP_ID));

                                                                String fobId = String.valueOf( struct.getLong(FOB_ID));

                                                                String fobName = struct.getString(FOB_NAME);

                                                                String targetCount = String.valueOf(struct.getLong(TARGET_COUNT));

                                                               

                                                                String keyForRedis = "FOB_"+groupIdStr+"_"+sessionId+"_"+gmmId+"_"+fobId;

                                                                String valueForRedis = groupIdStr+"_"+gmmId+"_"+fobId+"_"+fobName+"_"+targetCount;

                                                        
                                                               

                                                                client.set(keyForRedis, valueForRedis);

                                                                LOG.info("FOB Data Loading::keyForRedis" + keyForRedis.toString()+"\t FOB Data to Redis:"+valueForRedis);

                                                                //c.output(KV.of(groupIdStr+"_"+sessionId+"_"+gmmId, valueForRedis));

                                                               

                                                                c.output(KV.of(groupIdStr+"_"+sessionId+"_"+gmmId+"_"+fobId, valueForRedis));

                                                }

                                                resultSet.close();

                                }

                }

 

}