package com.macys.cyclecount;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.transforms.Create;
import org.apache.beam.sdk.transforms.Create.Values;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TupleTag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class DVNEnrichentFn extends DoFn<KV<String, Iterable<Row>>, KV<String,Row>> {
	private static final Logger LOG = LoggerFactory.getLogger(DVNEnrichentFn.class);
	private Spanner spanner = null;
	private DatabaseClient dbClient = null;
	final TupleTag<Row> mainOutputTag = new TupleTag<>("main");
	  final TupleTag<Row> additionalOutputTag = new TupleTag<>("unknownSide");
	 
	Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
			.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN").addStringField("DEPT_NBR")
			.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
	private Properties configProperties;

	public DVNEnrichentFn(Properties configProperties) {
		this.configProperties = configProperties;
	}

	@StartBundle
	public void startBundle(StartBundleContext c) {
		// TransactionFileOptions options =
		// c.getPipelineOptions().as(TransactionFileOptions.class);
		com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions.newBuilder()
				.build();
		spanner = spannerOptions.getService();
		String spannerProjectID = configProperties.getProperty("gcp.project.id");
		String spannerInstanceID = configProperties.getProperty("spanner.instance.id");
		String spannerDatabaseID = configProperties.getProperty("spanner.database.id");
		DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
		dbClient = spanner.getDatabaseClient(db);
	}

	@FinishBundle
	public void finishBundle(FinishBundleContext c) {
		try {
			dbClient = null;
			spanner.close();
			LOG.info("*************************Dept Vendor Enriched ************************");
		} catch (Exception e) {
			LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());
		}
	}

	@ProcessElement
	public void processElement(ProcessContext c) {
		KV<String, Iterable<Row>> keyValuepair = c.element();
		long invScanGrpId = Long.parseLong(keyValuepair.getKey());
		Iterable<Row> inputRow = keyValuepair.getValue();
		Values<Row> rows=Create.of(inputRow);
		
		Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);
		List<String> skuUpcNbrList = result.map(entry -> entry.getString("SKU_UPC_NBR")).collect(Collectors.toList());
		List<Long> longArrayList = skuUpcNbrList.stream().map(Long::parseLong).collect(Collectors.toList());
		long skuUpcNbr = 0;
		long deptNbr = 0;
		long vndNbr = 0;
		Map<String, String> materDataMap = new HashMap<>();
		Statement stmtToChkDeptVnd = Statement.newBuilder("select InvScanGrpId , ps.skuupcnbr, dvn.deptnbr, dvn.vndnbr "
				+ "from InvScanGrp grp "
				+ "join targetCntByDVN dvn on (dvn.ZlDivnNbr = grp.ZlDivnnbr and dvn.ZlStoreNbr = grp.ZlStoreNbr and dvn.CountDate = grp.CountDate) "
				+ "join prodsku ps on (ps.ZlDivnNbr = dvn.ZldivnNbr and ps.DeptNbr = dvn.DeptNbr and ps.VndNbr = dvn.vndnbr  and skuupcnbr in UNNEST( @skuUpcNbr) ) "
				+ "where grp.invscangrpid = @invScanGrpId ").bind("invScanGrpId").to(invScanGrpId).bind("skuUpcNbr")
				.toInt64Array(longArrayList).build();
		// LOG.info("Statement:::::::::" + stmtToChkDeptVnd.toString());
		ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtToChkDeptVnd);
		// LOG.info("Statement:::::::::");
		while (resultSet.next()) {
			Struct row = resultSet.getCurrentRowAsStruct();
			// LOG.info("Rows>>>>>>>>>>>>>>>>>>>>>>>>>>:::::::::" + row);
			deptNbr = row.getLong("deptnbr");
			vndNbr = row.getLong("vndnbr");
			skuUpcNbr = row.getLong("skuupcnbr");
			// LOG.info("Statement:::::::::" + skuUpcNbr);
			materDataMap.put(String.valueOf(skuUpcNbr), (deptNbr + "_" + vndNbr));
		}
		resultSet.close();
		Iterable<Row> inputRow1 = c.element().getValue();
		Stream<Row> result1 = StreamSupport.stream(inputRow1.spliterator(), false);
		result1.filter(entry -> entry != null).forEach(n -> c.output(KV.of(n.getString("INV_SCAN_GRP_ID"),n.withSchema(rfidScanEpcDataSchema)
				.withFieldValue("SCAN_TS", n.getString("SCAN_TS")).withFieldValue("USER_ID", n.getString("USER_ID"))
				.withFieldValue("SKU_UPC_NBR", n.getString("SKU_UPC_NBR"))
				.withFieldValue("EPC_URN", n.getString("EPC_URN")).withFieldValue("EPC_HEX", n.getString("EPC_HEX"))
				.withFieldValue("INV_SCAN_HDR_ID", n.getString("INV_SCAN_HDR_ID"))
				.withFieldValue("INV_SCAN_GRP_ID", n.getString("INV_SCAN_GRP_ID"))
				.withFieldValue("DEPT_NBR",
						materDataMap.get(n.getString("SKU_UPC_NBR")) != null
								? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[0]
								: "0")
				.withFieldValue("VND_NBR",
						materDataMap.get(n.getString("SKU_UPC_NBR")) != null
								? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[1]
								: "0")
				.build())));
		materDataMap.clear();
		// LOG.info("DeptVendor jsonString : ");
	}

}
