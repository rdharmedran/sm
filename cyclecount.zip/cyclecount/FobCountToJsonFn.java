package com.macys.cyclecount;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class FobCountToJsonFn extends DoFn<KV<Row, Iterable<Row>>, String> {
	private static final Logger LOG = LoggerFactory.getLogger(FobCountToJsonFn.class);
	/**
	*
	*/
	private static final long serialVersionUID = 1L;
	ObjectMapper objectMapper =null;

	@StartBundle

	public void startBundle(StartBundleContext c) {
		LOG.info("\n GMMCountToJsonFn>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started");
		 objectMapper = new ObjectMapper();
		objectMapper.configure(SerializationFeature.INDENT_OUTPUT, true);

	}

	@FinishBundle

	public void finishBundle(FinishBundleContext c) {
		LOG.info("\n GMMCountToJsonFn>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: finished");
		objectMapper = null;

	}

	@ProcessElement
	public void processElement(ProcessContext c) {
		
		try {
			LOG.info(c.element().getKey()+"\n GMMCountToJsonFn>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started"+c.element().getValue());

			 FobCountDetails details = new FobCountDetails();
			details.setGroupId(Long.parseLong(c.element().getKey().getString("INV_SCAN_GRP_ID")));
			details.setSessionId(Long.parseLong(c.element().getKey().getString("INV_SCAN_HDR_ID")));
			details.setGmmId(Long.parseLong(c.element().getKey().getString("GMM_ID")));
			// details.setTotalCount(totalCount);
			details.setZoneName("");
			final List<FobCount> fobCounts = new ArrayList<>();
			final Long totalTargetCount = 0l;
			final Iterable<Row> inputRow1 = c.element().getValue();
			final Iterator<Row> itr = inputRow1.iterator();
			while (itr.hasNext()) {
				final Row row = itr.next();

				final FobCount count = new FobCount(row.getString("FOB_ID"), row.getString("FOB_ID"),
						Long.parseLong(row.getString("COUNT")));
				fobCounts.add(count);
			}

			details.setTotalCount(totalTargetCount);
			details.setFobCounts(fobCounts);
			LOG.info("\n GMMCountToJsonFn>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>:: started"+objectMapper.writeValueAsString(details));
			c.output(objectMapper.writeValueAsString(details));
		} catch (final Exception e) {
			LOG.error("Init currentValue with zero", e);
			e.printStackTrace();
		}

	}
}
