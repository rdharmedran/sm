package com.macys.cyclecount;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.redis.RedisConnectionConfiguration;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Sum;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.macys.cyclecount.async.SpannerWriteDoFn;

import redis.clients.jedis.Jedis;

/**
 *
 * RFID Scanning Dataflow to read data from pubsub and write data
 *
 *
 *
 *
 *
 */
public class RFIDCycleCountStarter {
	
	private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleCountStarter.class);

	private static final String DEVICE_SCAN_DATA_SUBSCRIPTION = "device.scan.data.filtercount.subscription.name";

	private static final String ACTION_REQUEST = "actionRequest";

	private static final String SCAN_SESSION_ID = "scanSessionId";

	
	private static final String USER_ID = "userId";
	
	private static final String GROUP_ID = "groupId";
	
	public static final Schema gmmRowSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID").addStringField("COUNT").build();
	
	public static final  Schema fobRowSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID").addStringField("FOB_ID").addStringField("COUNT").build();

	public static final  Schema messageSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
			.addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
			.addStringField("EPC_URN").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
	
	public static final   Schema enrichedMessageSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")

			.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN").addStringField("DEPT_NBR")

			.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS")

			.addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("FOB_ID").addStringField("FOB_NAME")

			.build();
	
	public static final Schema notificationSchema = Schema.builder().addInt64Field(GROUP_ID).addInt64Field(SCAN_SESSION_ID)
			.addStringField(ACTION_REQUEST).addStringField(USER_ID).build();

	public static void main(String[] args) throws Exception {
		
		

		/* .................Loading configuration starts ................ */
		Properties configProperties = null;
		try {
			configProperties = RFIDCycleCountUtil.readPropertiesFile();
		} catch (final IOException e) {
			LOG.error("Error reading configuration file::" + e);
		}
		final PipelineOptions options = PipelineOptionsFactory.create();

		/* .................Loading configuration ends ................ */

	
		final Pipeline rfidScanPipeline = Pipeline.create(options);
		LOG.info("Pipeline started");

	
		/* ................. load lookup tables starts ................ */
		@SuppressWarnings("serial")
		final PCollectionView<Map<String, String>> displayEpcMap = rfidScanPipeline
				.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
				.apply(Window.<Long>into(new GlobalWindows())
						.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
						.discardingFiredPanes())
				.apply(ParDo.of(new DisplayTagLoader())).apply(View.<String, String>asMap());

		/* ................. load lookup tables ends ................ */
		;
		final PCollection<PubsubMessage> streamMessages = rfidScanPipeline.apply("Read from Pubsub",
				PubsubIO.readMessagesWithAttributes().withIdAttribute("UNIQUE_ID")
						.fromSubscription(configProperties.getProperty(DEVICE_SCAN_DATA_SUBSCRIPTION)));

		/*
		 * ---------------------------------- convert pubsub message to row object
		 * -------------------
		 */

		final PCollection<Row> streamRows = streamMessages
				.apply(ParDo.of(new PubsubMessageToRoW(messageSchema, false)));

		/*
		 * --------------- create micro batches for message with 30 seconds
		 * window---------------
		 */

		PCollection<Row> windowedStreamRows = streamRows.setCoder(RowCoder.of(messageSchema)).apply(Window
				.<Row>into(FixedWindows.of(Duration.standardSeconds(30)))
				.triggering(AfterWatermark.pastEndOfWindow()
						.withEarlyFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(0)))
						.withLateFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(0))))
				.withAllowedLateness(Duration.standardSeconds(0)).discardingFiredPanes());

		//final PCollection<Row> windowedscanData = windowedStreamRows.apply(ParDo.of(new PrintFn() ));

		/*
		 * ----------------------------group the message with group
		 * id---------------------
		 */
		final PCollection<KV<String, Row>> hdrGrpRows = windowedStreamRows
			//	.setCoder(RowCoder.of(messageSchema))
				.apply("Set EPC Header Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
								.via(row1 -> KV.of(row1.getString("INV_SCAN_HDR_ID"), row1)))
				.setRowSchema(messageSchema);

		final PCollection<KV<String, Iterable<Row>>> hdrKVRows = hdrGrpRows
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(messageSchema)))
				.apply(GroupByKey.<String, Row>create());

		/*------- remove display tag from stream using filter ----------------   */

		final PCollection<KV<String, Row>> displayremovedKV = hdrKVRows.apply("FilterDisplay Tags",
				ParDo.of(new DisplayTagRemoverFn(displayEpcMap)).withSideInputs(displayEpcMap));

	

		/*
		 * ------------------------ populate vendor number and department number by
		 * ---------
		 */
		final PCollection<KV<String, Iterable<Row>>> grpKVRows = displayremovedKV
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(messageSchema)))
				.apply(GroupByKey.<String, Row>create());
		
		
		final PCollection<KV<String, Row>> deptVndEnriched = grpKVRows
				
				.apply(ParDo.of(new DVNEnrichentFn2(configProperties)));
		
		deptVndEnriched.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(enrichedMessageSchema)));

		

		deptVndEnriched.apply("Calculate Group Count",
		new CalculateGroupCount(Duration.standardMinutes(1), configProperties));
			
			
		deptVndEnriched.apply("Calculate GMM Count",
				new CalculateGMMCount(Duration.standardMinutes(2), configProperties));
		
		
		deptVndEnriched.apply("Calculate Fob Count",
			new CalculateFOBCount(Duration.standardMinutes(3), configProperties));
		
		
		
		
		
		
		

		final PCollection<String> notificationJsons = rfidScanPipeline.apply("Read text File", TextIO.read().from(
				"C:\\Users\\180484\\Documents\\geoserver\\CCDataflow_Redis\\src\\main\\resources\\NotificationData.txt"));
		final PCollection<Row> notificationRows = notificationJsons.apply(ParDo.of(new DoFn<String, Row>() {
			@ProcessElement
			public void processElement(ProcessContext c) {
				final JSONObject notificationObj = new JSONObject(c.element());
				final long sessionId = notificationObj.getLong(SCAN_SESSION_ID);
				final long groupId = notificationObj.getLong(GROUP_ID);
				final String actionRequest = notificationObj.getString(ACTION_REQUEST);
				final String userId = notificationObj.getString(USER_ID);
				final Row row = Row.withSchema(notificationSchema).addValues(groupId, sessionId, actionRequest, userId)
						.build();
				c.output(row);
			}
		})).setCoder(RowCoder.of(notificationSchema));

// Action for start scan notification to load GMM Data
		notificationRows.apply(ParDo.of(new GMMDataLoader()))
				.setCoder(KvCoder.of(StringUtf8Coder.of(), StringUtf8Coder.of()));
		notificationRows.apply(ParDo.of(new FOBDataLoader()))
		;

		/* department vendor count starts here .............................. */

		/*
		 * final PCollection<KV<Row, Row>> rfidScanVendorKeyEpcDataByKV = dvnCollection
		 * .apply("Set DVN as  key",
		 * MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(),
		 * TypeDescriptors.rows())) .via(row1 -> KV.of(
		 * Row.withSchema(rfidScanVendorKeyEpcDataSchema)
		 * .addValues(row1.getString("INV_SCAN_GRP_ID"), row1.getString("DEPT_NBR"),
		 * row1.getString("VND_NBR")) .build(), row1)));
		 * 
		 * final PCollection<KV<Row, Iterable<Row>>>
		 * rfidScanVendorKeyEpcDataaGroupedRecords7 = rfidScanVendorKeyEpcDataByKV
		 * .setCoder(KvCoder.of(RowCoder.of(rfidScanVendorKeyEpcDataSchema),
		 * RowCoder.of(rfidScanEpcDataSchema))) .apply(GroupByKey.<Row, Row>create());
		 * 
		 * final PCollection<String> dvnCount = rfidScanVendorKeyEpcDataaGroupedRecords7
		 * .apply("DVN Count", ParDo.of(new DVNCountFn())) .apply("Take DVN Count",
		 * ParDo.of(new DVNCountToJsonFn()));
		 * dvnCount.apply("Write DVN Count To Pubsub",
		 * PubsubIO.writeStrings().to(configProperties.getProperty(
		 * "group.count.topic.name")));
		 * 
		 * final PCollection<KV<Row, Row>> rfidScanVendorSKUEpcDataByKV =
		 * dvnCollection.apply("Set SKU as  key",
		 * MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(),
		 * TypeDescriptors.rows())) .via(row1 ->
		 * KV.of(Row.withSchema(rfidScanVendorSKUCountSchema)
		 * .addValues(row1.getString("DEPT_NBR"), row1.getString("VND_NBR"),
		 * row1.getString("SKU_UPC_NBR"), row1.getString("INV_SCAN_GRP_ID")) .build(),
		 * row1)));
		 * 
		 * final PCollection<KV<Row, Iterable<Row>>>
		 * rfidScanVendorSKUDataaGroupedRecords7 = rfidScanVendorSKUEpcDataByKV
		 * .setCoder(KvCoder.of(RowCoder.of(rfidScanVendorSKUCountSchema),
		 * RowCoder.of(rfidScanEpcDataSchema))) .apply(GroupByKey.<Row, Row>create());
		 * 
		 * final PCollection<String> skuCount = rfidScanVendorSKUDataaGroupedRecords7
		 * .apply("DVN Count", ParDo.of(new SKUCountFn())) .apply("Take DVN Count",
		 * ParDo.of(new SKUCountToJsonFn()));
		 * skuCount.apply("Write DVN Count To Pubsub",
		 * PubsubIO.writeStrings().to(configProperties.getProperty(
		 * "group.count.topic.name")));
		 * 
		 */

		rfidScanPipeline.run().waitUntilFinish();
	}
}
