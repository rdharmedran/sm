
package com.macys.cyclecount;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "gmmName",
    "gmmId",
    "count"
})
public class GmmCount {

    public GmmCount(String gmmName, String gmmId, Long count) {
		super();
		this.gmmName = gmmName;
		this.gmmId = gmmId;
		this.count = count;
	}

	@JsonProperty("gmmName")
    private String gmmName;
    @JsonProperty("gmmId")
    private String gmmId;
    @JsonProperty("count")
    private Long count;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("gmmName")
    public String getGmmName() {
        return gmmName;
    }

    @JsonProperty("gmmName")
    public void setGmmName(String gmmName) {
        this.gmmName = gmmName;
    }

    @JsonProperty("gmmId")
    public String getGmmId() {
        return gmmId;
    }

    @JsonProperty("gmmId")
    public void setGmmId(String gmmId) {
        this.gmmId = gmmId;
    }

    @JsonProperty("count")
    public Long getCount() {
        return count;
    }

    @JsonProperty("count")
    public void setCount(Long count) {
        this.count = count;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

   
}
