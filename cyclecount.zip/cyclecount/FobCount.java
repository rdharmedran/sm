
package com.macys.cyclecount;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "fobName",
    "fobId",
    "count"
})
public class FobCount {

    public FobCount(String fobName, String fobId, Long count) {
		super();
		this.fobName = fobName;
		this.fobId = fobId;
		this.count = count;
	}

	@JsonProperty("fobName")
    private String fobName;
    @JsonProperty("fobId")
    private String fobId;
    @JsonProperty("count")
    private Long count;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("fobName")
    public String getFobName() {
        return fobName;
    }

    @JsonProperty("fobName")
    public void setFobName(String fobName) {
        this.fobName = fobName;
    }

    @JsonProperty("fobId")
    public String getFobId() {
        return fobId;
    }

    @JsonProperty("fobId")
    public void setFobId(String fobId) {
        this.fobId = fobId;
    }

    @JsonProperty("count")
    public Long getCount() {
        return count;
    }

    @JsonProperty("count")
    public void setCount(Long count) {
        this.count = count;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

   
}
